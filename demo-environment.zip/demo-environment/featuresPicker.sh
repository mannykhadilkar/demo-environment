#!/bin/sh
unset input
unset features
unset array
unset option
input="availableFeatures.csv"
while IFS=';' read -r col1 col2 col3 dummy
do
   features+=("$col1")
   array+=("$col1")
   array+=("$col2")
   if [ `printf '%s' ${(P)col1}` = "true" ]; then
     array+=("on")
   elif [ `printf '%s' ${(P)col1}` = "false" ]; then
     array+=("off")
   else
     array+=("$col3")
   fi
done < $input

option=$(dialog --checklist --output-fd 1 "Choose features:" 0 0 16 "${array[@]}")

exitstatus=$?
echo "\n\n"
if [ $exitstatus = 0 ]; then
    for feature in "${features[@]}"
    do
        case "${option[@]}" in 
          *$feature*)
            export $feature=true
            ;; 
          *) 
            export $feature=false
            ;;
        esac
    done
else
    echo "No changes applied"
fi
