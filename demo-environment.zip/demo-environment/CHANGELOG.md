# CHANGELOG

## 2020-01-07

* Added an example Azure function call
* The Deprecation Policy is now linked in the portal menu for visibility
* Brain / Immunity is now also target of the randomTrafficGenerator with some malicious requests.
* If you have the ENABLE_CUSTOM_PLUGINS set to true the /brain endpoint now generates errors and random latency
* randomTrafficeGenerator.sh now is the only script - it is also able to handle the loadbalanced scenario now
* K4k8s on Minikube now on Ingress Controller 0.7.0 / Kong Enterprise 1.4.2
* When stopping K4k8s on Minikube using the scripts Minikube is actually stopped. On restart it keeps running

## 2020-01-06

* All workspaces in all themes will now have a default admin and read role attached. 
* Admin and read-only users attached to all workspaces (but not activated, they need to go through the activation link process)
* Moved subScripts execution and workspace defaults to own scripts

## 2020-01-04

* Added role creation to freelyDefinableWorkspaces
* Update Kong admin api OpenAPI spec

## 2020-01-02

* Added billable plugin support

## 2019-12-30

* Added 8-example-themes with a collection of scripted themes and screenshots
* Added THEME_LOGO_URL which can be used for an external logo image URL (in this case THEME_LOGO_DATA is ignored)

## 2019-12-23
* Updated Brain & Immunity to 1.1.0

## 2019-12-20

* Added a /deprecated route based on IETF Draft [The Deprecation HTTP Header Field](https://tools.ietf.org/html/draft-dalal-deprecation-header-02). Also a deprecation policy is added to the dev portal (which is linked in deprecation header)
* Added THEME_HOMEPAGE_COMPANIES which is a space separated list of company names you want to be visible on the dev portal homepage. If empty or not set all workspaces names will be taken instead
* Updated to Kong Enterprise 1.3.0.1

## 2019-12-18

* new option in themePicker to enter workspaces names on the fly (will be added incl. example services and are in randomTrafficGenerator)

## 2019-12-17

* pre-function plugin demo added to K4k8s (two versions)

## 2019-12-16

* in 2-createContents we now have a folder with K4k8s specific deplyoment - some plugins already added
* Proxy Cache Advanced demo added to k4k8s

## 2019-12-14

* Added OpenAPI2Kong demo to 9-scripts/oas so that you can now demo importing an OAS spec into the proxy.

## 2019-12-13

* Due to the complexity of some plugin usage (like JWT or oauthIntrospection) I have added now the option to create sub-pages on the fly. In this change the named two are included already. This is meant to give us the freedom to add much more / longer / detailed documentation to the dev portal in an automated way (which is once again a great showcase for our dev portal being capable to do much more than only OpenAPI)

If you want to create your own pages in the developer portal on deployment time you simply need to copy or create a file in the folder `~/.demo-env/portalPages` of type Markdown / with the extension .md

See the scripts jwt.sh and oauthIntrospection.sh in the 2-createContents/subScripts folder for such files being copied (there is an env variable called "PORTAL_PAGES" you can use for convenience). 
Another example is the script `addDemoServices.sh` in the 2-createContents/theming folder which generates such a Markdown file on the fly (so you could basically do everything you can do in a shell script and add it to the Markdown file)

If you add a file called "myCoolMarkdown.md" it will be available in the portal at /myCoolMarkdown (no .md extension), for example `http://localhost:8003/myCoolMarkdown`

## 2019-12-12

* The added dev portals menus Demo-Services and Changelog are now located in a sub menu called Demo System to clean up some space for wieder logos
* Creation of demo services and changelog pages now in their own script for cleaner file structure, update to navigation also in own scrip
* Width of demo services and changelog now fits better in general dev portal layout 

## 2019-12-09

* Added ENABLE_THEME_ONLY_MODE to have a very fast restart available as well as to have a system being empty
* Minishift installation now on 1.3.0.0
* Minikube installation now on 1.3.0.0
* Minikube installation now updated to use latest manifests structure of K8s
* Added OpenShift 4.x deployment using CRC (see <https://code-ready.github.io/crc/>). CRC needs to be installed ad running before starting the deployment script

## 2019-12-04

* minikube-k4k8s demo env is now based on the Enterprise version of K4K8s
* in the 5-flows folder there is now a lightweight demo flow for K4K8s

## 2019-12-02

* This changelog is now pushed to the developer portal

## 2019-11-25

* In automated theming also the buttons border has the same color as the background

## 2019-11-22

* New features selection mode (featuresPicker.sh, checkPrerequesites.sh and more)
* ELK stack added (thanks to Degui!)
* Kafka add (Thanks to Aaron)
* Updated the license in K8s and OpenShift

## 2019-11-12

* Added a Let's Encrypt CA as example

## 2019-11-07

* Added a demo endpoint for a pre-function which adds data from an external service to upstream (/preFunctionEnrich)

## 2019-11-06

* We are now on Kong Enterprise 1.3.0.0

## 2019-11-01

* Added exit transformer example
* added degraphql example

## 2019-08-12

* Fixed OpenBanking theme script
* Fixed mtls-auth which had breaking changes in 0.36

## 2019-08-08

* Example for JWT signer added
* Severeal fixes to Minikube setup

## 2019-08-06

* Updated Kong Enterprise to 0.36 and Brain to 0.4.1
* Updated Bootstrap for /loginForm.html

## 2019-08-05

* Dev portal now has accounts for all Kong SEs

## 2019-08-01

* The createContents scripts now automatically creates in all workspaces the default service, route and add the Prometheus plugin. This used to be done in each script manually until now
* Renamed regional customer themes to from emeaCustomers.sh to customersEMEA.sh in order to get some easy to read consistency into all themes
* Added many themes with customers in verticals

## 2019-07-31

* Added new script in root directory for easy theme selection
* Added usCustomers theme
* Added emeaCustomers theme
* Added route by header
* The Demo Services page in dev portal now also shows links to Grafana and Syslog (on docker-compose only)

## 2019-07-30

* Reverted back to germanCarBrands as default 
* Added session plugin example
* Added jwt token example
* kong.sh script now also accepts restart

##  2019-07-29

General

* Kongflix is now the default theme if non found in $PORTAL_THEME
* Added new env variable THEME_WORKSPACE if the portal theming should not be done on default workspace. Your scripts must create this workspace and have the portal enabled on that workspace for this to work

Kongflix

* The scripts now automatically patches the Konglix Swagger so in dev portal correct host and basePath are used
* Changed all KongFlix routes to have /kongflix in order to have a clean structure
* Added names to all KongFlix-routes
* Added list of consumers to about page
* Removed data uri from about page

## 2019-07-26 

General

* Webserver added for deployment of static files (see WEBSERVER_HOST and WEBSERVER_PORT)
* Default workspace (in all themes) has now the Kong logo in Manager
* New scripts in 4-scripts/RBAC to enable and disable RBAC in docker-compose

Kongflix

* Kongflix theme added
* Kongflix homepage added
* Kongflix about page added

## 2019-07-25 

Brain

* Updated to Brain / Immunity 0.4.0
* Install scripts now changed to add Brain-Slack configuration on setup time
* Renamed brain plugin to collector plugin in createContents
* Checking for DISABLE_BRAIN on plugin setup
* kong.sh in root folder now automatically initiates Brain training if DISABLE_BRAIN is not set
* docker-compose setup yaml files have been splitted now in order to have a more flexible setup (for example DISABLE_BRAIN now also works with docker-compose)
* Added this changelog
