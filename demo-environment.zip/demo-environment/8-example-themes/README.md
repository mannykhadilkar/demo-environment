# Example themes

This is a collection of example themes for the developer portal as having been demoed in the past. They all have a screenshot and a shell script which can be used to replicate that design in the local demo env.

See [SCREENHOTS.md](./SCREENSHOTS.md) for a an overview

As always: `. ./chosenExampleTheme.sh` and then (re)start the demo env to pick it up.

Those example are meant to be a good starting point for demos and to create your own themes.

Note: this listing of demo themes is not meant to be shown to a customer/prospect as it of course includes real prospect names which they most likely do not wnat to be spread! 
