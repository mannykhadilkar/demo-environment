#!/bin/sh
echo "" > SCREENSHOTS.md
for image in ./*.jpg; do 
  echo "## $image\n" >> SCREENSHOTS.md
  echo "![alt text]($image)\n" >> SCREENSHOTS.md
done
