#!/bin/sh
http $ADMIN_HOST:$ADMIN_PORT/services name=goingElectric url=https://api.goingelectric.de/chargepoints
http $ADMIN_HOST:$ADMIN_PORT/services/goingElectric/plugins name=request-transformer config.append.querystring=key:afa1cb752c08c0bb779c23076ece33a9 -f
http $ADMIN_HOST:$ADMIN_PORT/services/goingElectric/routes name=goingElectricRoute paths=/goingElectric -f
