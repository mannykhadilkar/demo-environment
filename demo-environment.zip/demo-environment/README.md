# Automated demo enviroment setup
These scripts can be used to create a demo environment in one go and produce example calls to the exposed services.

## Work in progress

The first three working environments are docker-compose, minikube and minishift with more to come!

Some of the services require an external account or an external app (e.g. OpenID Connect with Google/Auth0/Azure/Okta) and will not work out of the box as redirect URI will be wrong on the app. Keycloak does work as it is Sven's personal server and has been configured with a wildcard redirect uri. 

New functions are available docker-compose first most of the time given it is the easiest to configure currently. This may change as our understanding and increased field usage of Kubernetes grows.

## Features overview

|Feature|docker-compose|Minikube|MiniShift|Kubernetes|Openshift|
|:------|------|------|------|------|:------|
|API Gateway|x|x|x|should work with Minikube yaml files|should work with MiniShift yaml files|
|Brain / Immunity|x|/ (no communiction gateway > collector)|-|-|-|
|Ingress Controller|n/a|x|x|-|-|

## Concept
These scripts generate a demo system with a working configuration which can be demoed right on the spot. As much as possible, dependencies on remote services have been removed, which facilitates an entirely local demo.

## Prerequisites
Next to the obvious need of Kong Enterprise and Docker/Kubernetes/OpenShift/Minishift/... the scripts are using HTTPie, yq, jq and dialog. Test your system with the script `./checkPrerequesites.sh` to find out about missing tools and how to install them.

Ensure the `KONG_LICENSE_DATA` environment variable is set to a valid license string. The latest demo license can be found [here](https://github.com/Kong/se-tools/blob/master/demo-license/kong-se-license.json).

One option is running inside of a Python virtual environment.

- Installed Python version 3.X: `brew install python3`
- Create a virtual environment inside any directory you want. `python3 -m venv ~/envs/default3` for example
- Activate the newly created environment: `. ~/envs/default3/bin/activate`. After you activate the environment, the default python interpreter will now be set to version 3.
- Install required libraries: `pip install httpie`, `brew install jq`

## Usage
The use of this demo environment we are working on is to make it as generic as possible so each deployment target shall behave in the same way.

These scripts and READMEs are not about the basic installation - so set up the desired system first (e.g. install Minikube, have kubectl up & running)

**Hint**: do *not* switch between different terminal windows while doing those steps as environment variables are important in all steps.

There is a script called `. ./featuresPicker.sh` (mind the leading "`. `" when starting it!) in the `demo-environment` root folder which lets you enable optional features like Brain/Immunity, LDAP, ELK, and more. All options are described in this tool.

The easiest way to launch (start) and tear down (stop) the demo environment is to use the `kong.sh` script located under `se-tools/demo-environment`.
```sh
kong.sh start|stop docker-compose|minikube|minishift|kubernetes|k8s|openshift
```
Additionally, you can run each portion of the setup, step by step as shown below.

1. Go into the `0-setup` folder and then it the folder of your desired system. (e.g. minikube). Run "`. ./install.sh`" there and follow the given instructions (yes, those are two dots separated by a space). 
2. Go into the `1-environment` folder and execute the script fitting your environment, for example "`. ./minikube.sh`". **Note: again, the "." in the beginning is important. It sets the env vars!**. After running the script, you'll get a listing of all IPs and ports being used and those are exported to environment variables available within your shell's session. So now you can do for example `http $ADMIN_HOST:$ADMIN_PORT/services` or `http://$PROXY_HOST:$PROXY_PORT/myOwnRoute`. The scripts in the following steps need those variables to be set in order to work!
3. The output from #2 also provides you Kong environment variables which you can use to update your deployment in Kubernetes/Openshift in order to make the UIs work. Those settings are already applied automatically by the install-script so portal and manager & dev portal should work out of the box.
4. Go into the `2-create-contents` folder and execute the `./createContents.sh [interactive]` script. Services, routes, plugins, workspaces and more will be created. The final output of the script is a list of created routes. If the optional parameter "interactive" is provided scripts may ask for details to overwrite defaults (for example usernames and passwords)
5. Go into the `3-generate-load` folder and start the script (the non-loadbalancer one is only used with docker-compose, all others use the loadbalancer branded). 
6. In the folder `4-clients` you may find example clients (configurations, scripts, URLs...). As starting point a Postman collection is included as well.
7. In the folder `5-flows` we are collecting demo scripts (both descriptions and if needed files like JSON or YAML)
8. In the folder `6-specs` you find a collection of OpenAPI / Swagger files for demoing imports and the dev portal
9. In the folder `9-scripts` you find many small helpful scripts
10. To delete your environment for a fresh setup, use the "`./delete.sh`" in each subfolder of `0-setup`

## Folders
All folders have their own `README.md` with more details.

### 0 Setup
Scripts and YAML files to create demo environment (for example docker-compose or K8s)

### 1 Environment
Have all the environment variables being set (for example to automatically fetch the exposed ports and hosts in Kubernetes)
Also you get a list of all valid user interface URLs.

### 2 Create content
Creates all services, routes, plugins, consumers and workspaces. Each plugin shall have its own route dedicated to its pure function. There is a script per plugin in the subScripts folder - use the existing ones as template if you want to add another demo route.

### 3 Generate load
The scripts generate load on all nodes and workspaces. In the default workspace also consumers are being used as well as errors being generated in order to see them in Manager

### 4 Clients
This folder shall be used for clients to the API calls being configured in `2-create-content`.

## Try it 
When everything has been set up you can for example try out the rate limited route as follows:

````
http $PROXY_HOST:$PROXY_PORT/rateLimiting
````

## Enabling RBAC

There is a script to enable / disable RBAC in the `9-scripts` folder, manually you can do it as follows:

1. Shell into each Kong container, kong-ent1, kong-ent2, kong-ent3 and enable RBAC:
   1. `$ docker-compose exec <kong_container> /bin/sh`
   1. `# export KONG_ENFORCE_RBAC=on`
   1. `# export KONG_ADMIN_GUI_SESSION_CONF='{"secret":"password" , "cookie_secure":false}'`
   1. `# export KONG_ADMIN_GUI_AUTH=basic-auth`
   1. `# kong reload; exit`
1. Now that Kong has been enabled for RBAC, to log on to Kong Manager use `kong_admin` with password `KongRul3z!`.  To use the Admin API, pass in the header the admin token `KongRul3z!` like so:
```
http :8001/workspaces Kong-Admin-Token:KongRul3z!
```

## Screenshots
### Enviroment variables have been set (script in `1-environment`)
![Environment](screenshots/environment.jpeg)

### Routes have been created (script in `2-create-contents`)
![Routes](screenshots/routesCreated.jpeg)

### Routes in Manager
![Routes in Manager](screenshots/routesInManager.jpeg)

### Manager with workspaces and graphs (load by `3-generate-load`)
![Manager](screenshots/manager.jpeg)

### Vitals (load by `3-generate-load`)
![Vitals](screenshots/vitals.jpeg)

### Deployment in Minikube
![Minikube](screenshots/minikube.jpeg)

### Deployment in Minishift
![Minishift](screenshots/minishift.jpeg)

