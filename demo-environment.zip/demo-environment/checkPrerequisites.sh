#!/bin/sh
echo "This scripts checks if all needed tools for automated setup of demo env are installed."
echo "The examples one how to install assumes you are on a recent macOS with Homebrew https://brew.sh, depending on your OS you might need to use another installation source/command"
echo "If there is no output beyond this line everything is fine"
if ! type "http" &> /dev/null; then
  echo ' * You are missing httpie - installation done by "brew install httpie"' 
fi
if ! type "jq" &> /dev/null; then
  echo ' * You are missing yq - installation done by "brew install jq"' 
fi
if ! type "yq" &> /dev/null; then
  echo ' * You are missing yq - installation done by "brew install yq"' 
fi
if ! type "grpcurl" &> /dev/null; then
  echo ' * You are missing grpcurl - installation done by "brew install grpcurl"' 
fi
if ! type "dialog" &> /dev/null; then
  echo ' * You are missing dialog - installation done by "brew install dialog"' 
fi
echo "All checks competed"
