#!/bin/sh

# --------------------------------------------
### Components
# --------------------------------------------

# unset DISABLE_BRAIN #enable Brain
# export DISABLE_BRAIN=TRUE #disable Brain

# unset ENABLE_BRAIN_IMMUNNITY
export ENABLE_BRAIN_IMMUNITY=true

# unset ENABLE_KAFKA
export ENABLE_KAFKA=true

# unset DISABLE_DATADOG # enable Datadog 
# export DISABLE_DATADOG=TRUE # disable Datadog

# export ENABLE_CUSTOM_PLUGINS=true # enable Custom Plugins

# export USE_INGRESS_CONTROLLER=true # use Ingress Controller
# unset USE_INGRESS_CONTROLLER

# if KIC is enabled then access to Manager and Portal is only possible using the hostnames provided by the script in 1-environment
# Right now Minikube only

# --------------------------------------------
###  Traffic Control
# Enable custom plugins
# export ENABLE_CUSTOM_PLUGINS=true

# --------------------------------------------
### Traffic Control

# --------------------------------------------
# export ENABLE_LOW_TRAFFIC_MODE=TRUE

# --------------------------------------------
###  Demo's Theme
# --------------------------------------------

## See 2-create-contents/subScripts/themes for possible themes (for example germanCarBrands, openBanking, starTrek or starWars)
export PORTAL_THEME=germanCarBrands

# --------------------------------------------
### Portal customization
# --------------------------------------------

## See 2-create-contents/subScripts/themes for possible themes (for example germanCarBrands, openBanking, starTrek or starWars)
# export PORTAL_THEME=starWars

# export THEME_WORKSPACE=KongFlix
# unset THEME_WORKSPACE


# export THEME_HEADER_COLOR=#f0f
# export THEME_LOGO_DATA="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAAAgCAYAAAAYEjShAAABfGlDQ1BJQ0MgcHJvZmlsZQAAKJFjYGAqSSwoyGFhYGDIzSspCnJ3UoiIjFJgv8PAzcDDIMRgxSCemFxc4BgQ4MOAE3y7xsAIoi/rgsxK8/x506a1fP4WNq+ZclYlOrj1gQF3SmpxMgMDIweQnZxSnJwLZOcA2TrJBUUlQPYMIFu3vKQAxD4BZIsUAR0IZN8BsdMh7A8gdhKYzcQCVhMS5AxkSwDZAkkQtgaInQ5hW4DYyRmJKUC2B8guiBvAgNPDRcHcwFLXkYC7SQa5OaUwO0ChxZOaFxoMcgcQyzB4MLgwKDCYMxgwWDLoMjiWpFaUgBQ65xdUFmWmZ5QoOAJDNlXBOT+3oLQktUhHwTMvWU9HwcjA0ACkDhRnEKM/B4FNZxQ7jxDLX8jAYKnMwMDcgxBLmsbAsH0PA4PEKYSYyjwGBn5rBoZt5woSixLhDmf8xkKIX5xmbARh8zgxMLDe+///sxoDA/skBoa/E////73o//+/i4H2A+PsQA4AJHdp4DTXElsAAAAGYktHRAAAADQAWciWH2MAAAAJcEhZcwAALiMAAC4jAXilP3YAAAAHdElNRQfjBgQMNR96BZdcAAAAGXRFWHRDb21tZW50AENyZWF0ZWQgd2l0aCBHSU1QV4EOFwAABbpJREFUeNrtnH9oVWUYx59z76a4rTB/DhJdRiDOUCsicllNaAQNJEHoj4J+zbAfREmMwP5JHGqY+o8KlhESmOgWRglBkiMctqWhJi5CW5nb3I+7e+49O+95n/d5+qP3yNtl855kOpnP56/Dud/7cnje+73f57zvuRfgJuH7/nRE3KWUegEEQbg1WLNmTRoR3yKiAWZmIurOZrMVUhlBGGfCMKwlorNcACJulOoIwjiRy+XmG2MO8igQUZDNZu+RSgnCOICIu7gIiLhfKiUI42PQGUQ0VMykURQ9JtUShPEx6TvFDGqMOSWVEoSbRBAES5RSSwEAzp49O5mIzhczqdb6JamcINxAfN+fiYh7bCqeiM+HYbiymEGJqEe2XQThBnDq1KlJiLiOmf2CVLz6MIIx5vsEC0abpJqCMIYopepHa2GJ6G9jTJnVLeLiDPu+f69UVRDGAET8KMG95QZHvztBih6QygrCGBAEwZIEqZjPZDLzAAByudwMIsomMPXjUl1BGAOMMZ8k2Eb5wknRdxPof2loaPCkuoJwHWSz2Tm+708FAPB9fzYR5YreXA4PLwMA6OrqmkxEnQlS9FWptCD8DwYGBqZorT9g5pwx5uP4vNa6MUEqdsR6pdSzCbZden3fv0OqLggJiKJotTHmomMgjYgL7L3lFGPM7wlS8UWnNT6awNRbpPKCcA2UUvcbY34YZcX1G9fACVKxWylVHo9LRFREH4ZheJ/MgiCMgNb6w2KmU0rVOanYmiBFNzoLRkm2XQ7JTAjCyG1tQ4JU/LWpqSkFADA8PLw0gX44/g1oFEUzE/7a5QmZDUEYAWPM6QSp+KaTip8muLf80tGvS6A/XVVVJdsugnA99Pf3P8XMHATBV0qpV6yvdl/rPdbYg1I9QShOSkogCLcuJU5LW6a1XsbM00pLS9vS6XQeAOYhYm9paemfAAB1dXVeS0tLTSqVqgKAjlwu547VAgAnAaDPPamUqvY87wFjzIUVK1b8ONJF5PP5+el0+hEAuNzZ2Xm8urp6YSqV8jzP67D3rGXGmEc9z6tMpVIdkyZNOidTJ9w2RFG0moj6C+7/frPt6HYAAK11TeGeJyJeGK3F1VrPLdymMcZ0ui1uFEXliNhSuCUTb8MAABDR8sJrI6IjRFQmMydMePL5fA0zk/3gHwjDcFtsztigQRDMZ+acNeV3VtMeawoN2tzcXBIvMhHRGas/7Iw5aFP7W2vcrjAMtxtj9sfX4hi0y77neSJ6iIgO2W2e9TJ7woSHiI7YLY3X3XaXiM7FBtVa77CarbGmsbExhYhHRjIoIq6y5uzo6emZ4oy7PjaoUupha84/Ll26NNVJ89cKDGqsbpPWuqavr29RFEXPBEGwWGZPmPAYY/JERLW1tV7B+fdigzLzT9agC1xNGIarRzHoDmuqta6+t7d3WmxQZm6wms2upr6+3nNb3CiK9o7wEEPr0NDQQpk9YaKTAoABz/O8w4cPT3NfYOa7nZTN2sNZ/1lhKimZPcq4A3aM6e7J8vLyOfExIip7WOlq9u3bd5fneVe/LNra2l5WSj1HRJ8z888AYNLpdE1FRcVBmT7hdlgg2mlT7Uh3d/dUm55PM3M+TlAiejv+Q7ChoaG5AABBECwmor9GStBMJvOgbXH9IAietPrZzHwsTlCt9SxmHiaiSCm1EgDgypUrd0ZR9LXzJNF8Zm5HxGMbNmwosYtPy+3YRmZPuB0WiWYw88X4Q4+IgwVPC20/c+bMZCJqdYzT52pGWsUlom2Ovr9gzEFrtjectnWQiNDV2S+Lk/baWqMoaiKiDqtvltkTbgt8368kor1ElKF/OU5EO5m5XWu9zhquDBG3ENFlm6bnwjDcwcztQRBsVUqtZOZ2Zn7faWPXGmPOx38khoib7ZhHHc0qRGy3Y/ZprXcbY04wc7tN1Uoi+swY0281PYi4J5PJyG9GhQnPP53dNZ1DgtbkAAAAAElFTkSuQmCC"
# export THEME_WELCOME_TITLE="Welcome to my dev portal"
# export THEME_WELCOME_TEXT="This is the text on the homepage"
# THEME_WELCOME_BACKGROUND_TEXT_BOX=true
# unset THEME_WELCOME_BACKGROUND_TEXT_BOX
# export THEME_WELCOME_BACKGROUND_COLOR=#123
# export THEME_WELCOME_BACKGROUND_IMAGE_URL="https://business.nasdaq.com/media/Market-Data-Landing-Page-IMAGES_GIS-598x218-4_tcm5044-61254.jpg"

# Custom CSS examples
# 1 Change color of buttons
# export THEME_CUSTOM_CSS=".button-success { background-color: #0996c7 !important}\n.button-primary { background-color: #0996c7 !important}\nh1 { color: #0996c7}"
# 2 Change navigation bar entries to black font (needed if the header color is light / white
# export THEME_CUSTOM_CSS='.button-success { background-color: #FA9C1F !important} .button-primary { background-color: #FA9C1F !important} h1 {color: #008296} ul.navigation > li > a { color: #000 !important} nav.header-login-container > li > a { color: #000 !important} nav.header-login-container > li > a.button { background-color: #FA9C1F !important} #header {box-shadow: 0px 2px 6px rgba(0,0,0,0.1);} ul.footer-links > li > a { color: #444 !important} '


# export THEME_WORKSPACE=KongFlix
# unset THEME_WORKSPACE
