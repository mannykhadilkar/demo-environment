#!/bin/sh
VALID_ENVS="docker-compose minikube minikube-k4k8s minishift kubernetes k8s crc"

if [ $# -lt "2" ]
then
  echo "This script needs at least two parameters:"
  echo " 1st: start/stop/restart"
  echo " 2nd: name of environment: $VALID_ENVS"
  echo "Example . ./kong.sh start minikube"
  exit
fi  

start() {
    case $1 in
      docker-compose)
        echo starting docker-compose
        cd 0-setup/docker-compose
        ./install.sh
        cd ../../1-environment
        . ./docker-compose.sh
        echo "Waiting 5 seconds for the enviroment to come up..."
        sleep 5
        cd ../2-create-contents
        if [ "$ENABLE_QUIET_PUBLISH" = true ] ;
        then
          ./createContents.sh >/dev/null
        else
          ./createContents.sh  
        fi
        cd ..
        if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ;
        then
          ./3-generate-load/brain_trainer.sh 
        fi
        ;; 

      minikube)
        echo starting MiniKube
        cd 0-setup/minikube
        ./install.sh
        cd ../../1-environment
        . ./minikube.sh
        echo "Waiting 45 seconds for the enviroment to come up..."
        sleep 45
        cd ../2-create-contents
        ./createContents.sh
        cd ..
        if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ;
        then
          ./3-generate-load/brain_trainer.sh 
        fi
        ;; 
	  docker-k8s)
	    echo starting docker-k8s
	    cd 0-setup/docker-k8s
	    ./install.sh
        cd ../../1-environment
        . ./docker-k8s.sh
        echo "Waiting 45 seconds for the enviroment to come up..."
        sleep 45
        cd ../2-create-contents
        if [ "$ENABLE_QUIET_PUBLISH" = true ] ;
        then
          ./createContents.sh >/dev/null
        else
          ./createContents.sh  
        fi
        cd ..
        if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ;
        then
          ./3-generate-load/brain_trainer.sh 
        fi	    
	    ;;
      minikube-k4k8s)
        echo starting MiniKube K4K8s
        cd 0-setup/minikube-k4k8s
        ./install.sh
        cd ../../1-environment
        . ./minikube-k4k8s.sh
        ;; 
      docker-k8s)
	    echo starting docker-k8s
	    cd 0-setup/docker-k8s
	    ./install.sh
        cd ../../1-environment
        . ./docker-k8s.sh
        echo "Waiting 45 seconds for the enviroment to come up..."
        sleep 45
        cd ../2-create-contents
        ./createContents.sh
        cd ..
        if [ -z "$DISABLE_BRAIN" ]
        then
          ./3-generate-load/brain_trainer.sh 
        fi	    
	    ;;
      minishift)
        echo starting MiniShift
        cd 0-setup/minishift
        ./install.sh
        cd ../../1-environment
        . ./minishift.sh
        echo "Waiting 30  seconds for the enviroment to come up..."
        sleep 30
        cd ../2-create-contents
        ./createContents.sh
        cd ..
        ;; 
      crc)
        echo starting CRC
        cd 0-setup/crc
        ./install.sh
        cd ../../1-environment
        . ./crc.sh
        echo "Waiting 30  seconds for the enviroment to come up..."
        sleep 30
        cd ../2-create-contents
        ./createContents.sh
        cd ..
        ;; 
      kubernetes)
        echo "Not supported right now but Minikube/Minishift scripts should work fine for installation"
        ;;
      k8s)
        echo "Not supported right now but Minikube/Minishift scripts should work fine for installation"
        ;;
      openshift)
        echo "Not supported right now but Minikube/Minishift scripts should work fine for installation"
        ;;
      *)
        echo "Unknown environment, only use $VALID_ENVS"
        ;;        
        
    esac
}

stop() {
    case $1 in
      docker-compose)
        echo stopping docker-compose
        cd 0-setup/docker-compose
        ./delete.sh
        cd ../../
        ;; 
      minikube)
        echo stopping Minikube
        cd 0-setup/minikube
        ./delete.sh
        cd ../../
        ;; 
      minikube-k4k8s)
        echo stopping Minikube K4K8s
        cd 0-setup/minikube-k4k8s
        ./delete.sh
        cd ../../
        ;; 
      docker-k8s)
        echo stopping docker-k8s
        cd 0-setup/docker-k8s
        ./delete.sh
        cd ../../
        ;;         
      minishift)
        echo stopping Minishift
        cd 0-setup/minishift
        ./delete.sh
        cd ../../
        ;; 
      crc)
        echo stopping CRC
        cd 0-setup/crc
        ./delete.sh
        cd ../../
        ;; 
      kubernetes)
        echo "Not supported right now but Minikube/Minishift scripts should work fine for installation"
        ;;
      k8s)
        echo "Not supported right now but Minikube/Minishift scripts should work fine for installation"
        ;;
      openshift)
        echo "Not supported right now but Minikube/Minishift scripts should work fine for installation"
        ;;
      *)
        echo "Unknown environment, only use $VALID_ENVS"
        ;;
    esac
}

case $1 in
  start)
    echo $2
    start $2
  ;; 
  stop)
    stop $2
  ;;
  restart)
    export ENV_IN_RESTART=true
    stop $2
    start $2
    unset ENV_IN_RESTART
  ;;
  *)
    echo "First parameter either needs to be \"start\", \"stop\" or \"restart\""
    ;;
esac

