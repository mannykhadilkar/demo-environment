#!/bin/sh

http -f $ADMIN_HOST:$ADMIN_PORT/services name=httpbin url=http://httpbin/anything
http -f $ADMIN_HOST:$ADMIN_PORT/services name=placeholder url=http://placeholder:3000
http -f $ADMIN_HOST:$ADMIN_PORT/services name=user url=http://placeholder:3000/users/1
http -f $ADMIN_HOST:$ADMIN_PORT/services name=serverless url=http://dummy.example.com

# creating generic demo user
http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=demo@apim.eu custom_id=demo@apim.eu

for script in ./subScripts/*.sh; do
  sleep 0.1s
  echo "********** executing $script"
  . "$script"
done
