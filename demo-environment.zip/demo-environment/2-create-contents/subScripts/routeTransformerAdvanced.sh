#!/bin/sh
http $ADMIN_HOST:$ADMIN_PORT/services name=httpbin-transformed url=http://httpbin.org/anything
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin-transformed/routes name=route-transformer-example paths="/routeTransformer"
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin-transformed/plugins name=route-transformer-advanced config.path="/headers" enabled=false

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/routeTransformer> The Route Transformer Advanced Plugin demonstrates re-mapping a service's path (and/or host and/or port). If the plugin is enabled, this demo shows remapping the configured /anything path to the /headers path.\n"
