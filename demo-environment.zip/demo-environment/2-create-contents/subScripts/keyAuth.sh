#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=key-auth paths:='["/keyAuth"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=key-auth

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/keyAuth> Keys are for example gold, silver or developer\n"
