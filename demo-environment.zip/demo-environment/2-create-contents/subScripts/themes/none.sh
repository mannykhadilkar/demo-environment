#/bin/sh
echo "No workspaces generated"
