#!/bin/sh
echo "Please enter all the workspaces you want to be created - seperated by spaces"
echo "Default is coming from the value of the variable THEME_WORKSPACES, e. g 'export THEME_WORKSPACES=\"one two three\"'"
read -p "Workspaces [$THEME_WORKSPACES]: " list
list=${list:-$THEME_WORKSPACES}
workspaces=(`echo ${list}`);
for workspace in "${workspaces[@]}"
do
 echo "Adding workspace $workspace"
 http -f $ADMIN_HOST:$ADMIN_PORT/workspaces/ name=$workspace
done
