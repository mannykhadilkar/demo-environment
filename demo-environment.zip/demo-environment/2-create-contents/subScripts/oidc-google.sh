#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oidc-google paths:='["/oidcGoogle"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=svenwal@gmail.com custom_id=svenwal@gmail.com
http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=marco.marquez.b@gmail.com custom_id=marco.marquez.b@gmail.com

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=openid-connect \
config.issuer=https://accounts.google.com/.well-known/openid-configuration \
config.client_id="815961418228-4pc4i7c81nk14m9a0s03n701vjs5so96.apps.googleusercontent.com" \
config.client_secret="e_EgO46CwLbwgxvkKKVRJQzc" \
config.consumer_optional=true \
config.ssl_verify=false \
config.consumer_claim=email \
config.verify_signature=false \
config.verify_parameters=false \
config.redirect_uri=http://$PROXY_HOST:$PROXY_PORT/oidcGoogle

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oidcGoogle>\n"
