#!/bin/sh
if [ "$ENABLE_SYSLOG" = true ] ; 
then
  http -f $ADMIN_HOST:$ADMIN_PORT/plugins name=udp-log config.host=syslog config.port=514
fi
