#!/bin/sh

if [ "$ENABLE_DATADOG" = true ] ; 
then
  ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=datadog paths:='["/datadog"]' | jq -r '.id' )
  http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=datadog config.host=datadog config.port=8125
  export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/datadog>\n"
fi

