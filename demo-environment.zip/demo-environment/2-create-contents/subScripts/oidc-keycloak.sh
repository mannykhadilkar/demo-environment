#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oidc-keycloak paths:='["/oidcKeycloak"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=openid-connect \
config.issuer=https://keycloak.apim.eu/auth/realms/kong/.well-known/openid-configuration \
config.client_id=client1 \
config.client_secret=aeb992d5-4be4-4125-857b-6210776321d2 \
config.ssl_verify=false \
config.consumer_claim=email \
config.verify_signature=false \
config.redirect_uri=http://$PROXY_HOST:$PROXY_PORT/oidcKeycloak

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oidcKeycloak>  Keycloak-user demo@apim.eu, Keycloak-password KongRul3z!\n"
