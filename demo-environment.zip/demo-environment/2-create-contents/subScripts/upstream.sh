#!/bin/sh
http $ADMIN_HOST:$ADMIN_PORT/upstreams name=httpbinUpstream
http $ADMIN_HOST:$ADMIN_PORT/upstreams/httpbinUpstream/targets target=httpbin.org:80
http $ADMIN_HOST:$ADMIN_PORT/upstreams/httpbinUpstream/targets target=httpbin.apim.eu:80

http $ADMIN_HOST:$ADMIN_PORT/services name=loadBalancedUpstream url=http://httpbinUpstream/anything
http $ADMIN_HOST:$ADMIN_PORT/services/loadBalancedUpstream/routes name=upstream paths:='["/upstream"]'

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/upstream> (httpbin.org and httpbin.apim.eu as targets)\n"
