#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=route-by-header paths="/routeByHeader"

curl -i -X POST http://$ADMIN_HOST:$ADMIN_PORT/routes/route-by-header/plugins -H 'Content-Type: application/json' --data '{"name": "route-by-header", "config": {"rules":[{"condition": {"version":"v2"}, "upstream_name": "httpbin.org"}, {"condition": {"online":"true"}, "upstream_name": "httpbin.org"}]}}'
# spacing after curl command
echo "\n"
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/routeByHeader> - default it goes to httpbin (in Docker), when providing version:v2 or online:true it'll take online httpbin.org instead\n "
