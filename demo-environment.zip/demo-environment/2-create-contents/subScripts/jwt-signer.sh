#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=jwt-signer-route paths="/jwtSigner" protocols="http"

COUNTER=0
while [ $COUNTER -lt 5 ]; do
  if http --check-status -f $ADMIN_HOST:$ADMIN_PORT/routes/jwt-signer-route/plugins name=jwt-signer config.access_token_jwks_uri='https://keycloak.apim.eu/auth/realms/kong/protocol/openid-connect/certs' config.channel_token_optional=true; then 
    break
  fi
  let COUNTER=COUNTER+1
  echo "Trying again $COUNTER of 5"
done

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/jwtSigner> use \`token=\$(http $PROXY_HOST:$PROXY_PORT/oidcKeycloak Authorization:'Basic demo@apim.eu:KongRul3z!'|jq -r .headers.Authorization)\` to generate 1st token then use that as input for \`http $PROXY_HOST:$PROXY_PORT/jwtSigner/anything Authorization:\"\$token\"|jq -r .headers.Authorization\`. Compare the two tokens using <https://jwt.io/> noting the iss and original_iss fields.\n"
