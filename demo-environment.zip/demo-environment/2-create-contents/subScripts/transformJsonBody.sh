#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/user/routes name=no-transformation paths:='["/transformNothing"]' | jq -r '.id' )
ROUTE_ID_TRANSFORM=$(http $ADMIN_HOST:$ADMIN_PORT/services/user/routes name=transformation paths:='["/transform"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID_TRANSFORM/plugins name=response-transformer config.add.json=myNewProperty:myNewValue config.remove.json=phone config.replace.json=email:***** config.append.headers=X-Kong-Added-Header:myAddedHeaderValue

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/transformNothing>\n"
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/transform> (same as /transformNothing but adds, changes and removes a JSON property and adds a header)\n"
