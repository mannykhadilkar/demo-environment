# Notes for adding scripts

If you add a script here which references another file (like importing a JSON or similar) make sure the provided path is relative to the 2-create-contents folder and not to the subsScripts folder. Otherwise scripts will fail as they won't find the needed file. Typically this means instead of "myCommand < ./myFile.json" it instead needs to be "myCommand < ./subScripts/myFile.json"
