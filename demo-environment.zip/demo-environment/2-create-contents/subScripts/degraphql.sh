#Creating Service
http $ADMIN_HOST:$ADMIN_PORT/services name=degraphql-service url=https://api.github.com

#Creating Route
http -f $ADMIN_HOST:$ADMIN_PORT/services/degraphql-service/routes name=degraphql-route paths="/dql"

#Applying Plugin
http -f $ADMIN_HOST:$ADMIN_PORT/services/degraphql-service/plugins name=degraphql

#Configuring Plugin
http $ADMIN_HOST:$ADMIN_PORT/services/degraphql-service/degraphql/routes uri=/kong query='query { organization (login:"kong") {  description location repository(name: "kong") { description } } }'

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/dql/kong> use \`http $PROXY_HOST:$PROXY_PORT/dql/kong Authorization:\"Bearer \$GH_TOKEN\"\` to make a RESTful call to a GraphQL API. Needs a GitHub bearer token (read:org) for authentication.\n"
