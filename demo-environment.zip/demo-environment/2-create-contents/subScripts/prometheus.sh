#!/bin/sh
if [ "$ENABLE_PROMETHEUS_GRAFANA" = true ] ; 
then
  http -f $ADMIN_HOST:$ADMIN_PORT/plugins name=prometheus 
fi
