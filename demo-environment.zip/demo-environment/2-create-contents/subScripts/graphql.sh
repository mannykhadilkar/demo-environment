#Creating Services
http $ADMIN_HOST:$ADMIN_PORT/services name=graphql url=https://api.github.com/graphql

#Creating Route
http -f $ADMIN_HOST:$ADMIN_PORT/services/graphql/routes name=graphql paths="/graphql"

#Applying Plugin
http -f $ADMIN_HOST:$ADMIN_PORT/routes/graphql/plugins name=graphql-proxy-cache-advanced config.strategy=memory enabled=false

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/graphql> Needs a GitHub bearer token (read:org) for authentication. Make a POST request - see <https://github.com/Kong/se-tools/tree/master/summit-demo>\n"
