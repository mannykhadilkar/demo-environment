#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=proxy paths="/proxy"

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/proxy>\n"
