#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=acl paths:='["/acl"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=key-auth
http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=acl config.whitelist=aclGroup1 -f

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=acl11
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl11/key-auth key=acl11
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl11/acls group=aclGroup1

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=acl12
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl12/key-auth key=acl12
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl12/acls group=aclGroup1

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=acl21
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl21/key-auth key=acl21
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl21/acls group=aclGroup2

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=acl22
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl22/key-auth key=acl22
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/acl22/acls group=aclGroup2

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/acl> apikey allowed acl11, acl12 - disallowed acl21,acl22 (and all others)\n"
