#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=basic-auth paths:='["/basicAuth"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=basic-auth
http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=basic
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/basic/basic-auth username=basic password=auth

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/basicAuth> (username basic, password auth)\n"
