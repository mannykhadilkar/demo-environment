#!/bin/sh
if [ "$ENABLE_ELK" = true ]
then
  echo "Checking if Kibana has started..."
  while true
    do
      STATUS_CODE=$(curl -s -o /dev/null -w "%{http_code}" $KIBANA_HOST:$KIBANA_PORT/api/kibana/dashboards/)
      if [ $STATUS_CODE -eq 301 ]; then
        echo "OK"
        break
      else
        echo "Not yet. Got status: $STATUS_CODE"
        sleep 3s
      fi
  done
  sleep 3s
  http post http://$KIBANA_HOST:$KIBANA_PORT/api/kibana/dashboards/import kbn-xsrf:true < ../0-setup/shared/elk/dashboard.json
fi
