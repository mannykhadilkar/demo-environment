#!/bin/sh
http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=deprecated paths='/deprecated' -f

http -f $ADMIN_HOST:$ADMIN_PORT/routes/deprecated/plugins name=response-transformer-advanced config.append.headers="Deprecation:Sun, 11 Nov 2018 23:59:59 GMT" config.append.headers="Link:<http\://$PROXY_HOST\:$PROXY_PORT/proxy>; rel=\"successor-version\", <http\://$PORTAL_HOST\:$PORTAL_PORT/deprecated>; rel=\"deprecation\"" config.append.headers="Sunset:Wed, 11 Nov 2020 23:59:59 GMT"

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/deprecated> This will add deprecation headers based on IETF Draft [The Deprecation HTTP Header Field](https://tools.ietf.org/html/draft-dalal-deprecation-header-02). Also a deprecation policy is added to the dev portal at <http://$PORTAL_HOST:$PORTAL_PORT/deprecated> (which is linked in deprecation header)\n"
cp ./subScripts/deprecated.md $PAGES_FOLDER
