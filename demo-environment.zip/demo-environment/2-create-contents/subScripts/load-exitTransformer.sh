#!/bin/sh
# Altering script name so it loads AFTER Key Auth plugin configuration step
http -f $ADMIN_HOST:$ADMIN_PORT/routes/key-auth/plugins name=exit-transformer config.functions=@./subScripts/exit-transformer.lua enabled=false

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * Exit Transformer Plugin Demo -- make a call to \`http $PROXY_HOST:$PROXY_PORT/keyAuth\` without any auth, note the error, then enable the Exit Transformer plugin and note the customized error.\n"
