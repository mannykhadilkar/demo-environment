#!/bin/sh
if [ "$ENABLE_REDIS" = true ] ; 
then
  http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=redis-cache paths="/redisCache"
  http -f $ADMIN_HOST:$ADMIN_PORT/routes/redis-cache/plugins name=proxy-cache-advanced config.strategy=redis config.redis.database=1 config.redis.host=redis config.redis.password=kong config.redis.port=6379
  export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/redisCache>\n"
fi
