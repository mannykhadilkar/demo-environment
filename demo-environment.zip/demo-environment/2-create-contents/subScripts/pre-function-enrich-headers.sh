#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=pre-function-enrich paths="/preFunctionEnrich"
http -f $ADMIN_HOST:$ADMIN_PORT/routes/pre-function-enrich/plugins name=pre-function config.functions=@./subScripts/pre-function-enrich-headers.lua
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/preFunctionEnrich> this function will look for a header called x-uuid - if it is not present it fetches one from <http://httpbin.org/uuid> and adds it to the backend call. Example for request enrichment with external source\n"
