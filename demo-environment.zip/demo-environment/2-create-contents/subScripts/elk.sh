#!/bin/sh
if [ "$ENABLE_ELK" = true ]
then
  http -f $ADMIN_HOST:$ADMIN_PORT/plugins name=tcp-log config.host=logstash config.port=5044
fi
