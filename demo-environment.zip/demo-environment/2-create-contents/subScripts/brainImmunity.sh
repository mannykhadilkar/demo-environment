#!/bin/sh
if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ; 
then
  ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/placeholder/routes name=brain paths:='["/brain"]' | jq -r '.id' )
  http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=collector config.service_token=foo config.host=$COLLECTOR_HOST config.port=$COLLECTOR_PORT config.https=false config.log_bodies=true config.connection_timeout=100

  if [ "$ENABLE_CUSTOM_PLUGINS" = true ] ; 
  then
    http $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=inject-errors config.status_codes=500 config.percentage_error=20 config.percentage_latency=33 -f
  fi

  export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/brain>\n"

fi
