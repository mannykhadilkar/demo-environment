#!/bin/sh

# check if certificate has been created already
if [ ! -d ~/.demo-env/certificates/mTLSbackend/ ] 
then
  . ./helpers/createTlsCertificates.sh 
fi

ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=mtls-auth paths:='["/mtls-auth"]' | jq -r '.id' )

CERT_ID=$(http -f $ADMIN_HOST:$ADMIN_PORT/ca_certificates cert@$HOME/.demo-env/certificates/mTLSbackend/ca/certs/ca.cert.pem tags=ownCA  | jq -r '.id' )
LETSENCRYPT_CERT_ID=$(http -f $ADMIN_HOST:$ADMIN_PORT/ca_certificates cert@subScripts/letsEncryptRootCA.pem tags=letsencrypt  | jq -r '.id' )
http $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=mtls-auth config:="{\"ca_certificates\": [\"$CERT_ID\"]}"

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <https://$PROXY_HOST:$PROXY_SSL_PORT/mtls-auth> access granted with \`http --verify=no --cert=$HOME/.demo-env/certificates/mTLSbackend/client/1337.pem --cert-key=$HOME/.demo-env/certificates/mTLSbackend/client/client.key https://$PROXY_HOST:$PROXY_SSL_PORT/mtls-auth\`\n"
