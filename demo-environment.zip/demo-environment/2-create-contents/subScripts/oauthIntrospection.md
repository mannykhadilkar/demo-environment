
# OAuth Introspection usage details

* First we need to create an access token. In our example endpoint we are using the Keycloak of Sven.

Either go into 4-clients folder and import the Postman collection into your Postman (which will provide you with a collection of demo-services related calls including the call to create the access token) or you can also use httpie:

`http https://keycloak.apim.eu/auth/realms/kong/protocol/openid-connect/token grant_type=password client_id=client1 client_secret=aeb992d5-4be4-4125-857b-6210776321d2 username=demo password=KongRul3z! -f`

Copy from the response the value of "access_token" and use it as described as a header like for example `http localhost:8000/oauthIntrospection 'Authorization:Bearer THE_COPIED_ACCESS_TOKEN'`