#Creating Services
http $ADMIN_HOST:$ADMIN_PORT/services name=grpc-service url=grpc://grpcb.in:9000

#Creating Route. Setting content-type to avoid 415 error and receive expected 404
http -f $ADMIN_HOST:$ADMIN_PORT/services/grpc-service/routes name=grpc-route paths="/" protocols="grpc" protocols="grpcs" headers.content-type="application/grpc"

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$HTTP2_PROXY_PORT> Make a grpc call \`grpcurl -v -d '{\"greeting\":\"Kong 1.3!\"}' -plaintext $PROXY_HOST:$HTTP2_PROXY_PORT hello.HelloService.SayHello\`\n"
