
# Deprecation Policy

We will announce if we intend to discontinue or make backwards incompatible changes to this API or Service. We will use commercially reasonable efforts to continue to operate those APIs versions and features until the date found in the sunset header of the API response:

* required by law or third party relationship (including if there is a change in applicable law or relationship), or
* doing so could create a security risk or substantial economic or material technical burden.

The above policy is the "Deprecation Policy." 
