#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oauth-route paths="/oauthProtected"

http -f $ADMIN_HOST:$ADMIN_PORT/routes/oauth-route/plugins name=oauth2 config.scopes="email" config.scopes="phone" config.scopes="address" config.mandatory_scope=true config.enable_client_credentials=true config.enable_authorization_code=true config.enable_implicit_grant=true config.enable_password_grant=true config.provision_key=myProvisionKey1

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=oauthUser
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/oauthUser/key-auth key=endUserKey

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=oauthApp
http $ADMIN_HOST:$ADMIN_PORT/consumers/oauthApp/oauth2 name="Kong OAuth App" client_id="myClientId1" client_secret="myClientSecret1" redirect_uris:='["http://localhost:8000/oauthProtected"]'

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oauthProtected> use \`http POST 'https://localhost:8443/oauthProtected/oauth2/token?grant_type=client_credentials&client_id=myClientId1&client_secret=myClientSecret1&scope=email' --verify=no\` to generate an access token.\n"
