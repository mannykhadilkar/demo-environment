#!/bin/sh

if [ $ENABLE_KAFKA = true ]; then
  #Creating Route
  http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=kafka-route paths="/kafka"

  #Setting up Kafka
  docker exec -it kafka bash /opt/bitnami/kafka/bin/kafka-topics.sh --zookeeper zookeeper:2181 --topic kong-log --create --partitions 3 --replication-factor 1

  #Configuring Kafka Log Plugin
  http -f :8001/routes/kafka-route/plugins name=kafka-log config.bootstrap_servers[1].host=kafka config.bootstrap_servers[1].port=9092 config.topic=kong-log

  export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/kafka> Examine Kafka \`docker exec -it kafka bash /opt/bitnami/kafka/bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic kong-log --from-beginning\` and then run some traffic through Kong \`for i in {1..10} ; do curl http://localhost:8000/kafka/\$i ; sleep 1; done\`\n"

else

  echo "Kafka not enabled."

fi
