#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oauth-introspection paths:='["/oauthIntrospection"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=oauth2-introspection config.introspection_url=https://keycloak.apim.eu/auth/realms/kong/protocol/openid-connect/token/introspect config.authorization_value="Basic Y2xpZW50MTphZWI5OTJkNS00YmU0LTQxMjUtODU3Yi02MjEwNzc2MzIxZDI=" config.token_type_hint=requesting_party_token

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oauthIntrospection> See [this page](/oauthIntrospection) for more details on token generation\n"
cp ./subScripts/oauthIntrospection.md $PAGES_FOLDER
