#!/bin/sh
curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/services/   --data 'name=combined'  --data 'url=http://httpbin/anything'
echo "\n"
curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/services/combined/routes --data 'name=combined'  --data 'hosts[]=kong' --data 'paths[]=/httpbin'


curl -i -X GET   --url http://$ADMIN_HOST:$PROXY_PORT/httpbin   --header 'Host: kong'
curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/services/combined/plugins/   --data 'name=key-auth'

curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/consumers/   --data 'username=myConsumer'
curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/consumers/myConsumer/key-auth/   --data 'key=httpbinKey'

curl -i -X GET   --url http://$ADMIN_HOST:$PROXY_PORT/httpbin   --header 'Host: kong'   --header 'apikey: httpbinKey'

curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/consumers/   --data 'username=anotherConsumer'
curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/consumers/anotherConsumer/key-auth/   --data 'key=anotherKey'

curl -i -X POST   --url http://$ADMIN_HOST:$ADMIN_PORT/services/combined/plugins/ --data "name=basic-auth"  --data "config.hide_credentials=true"
curl -X POST http://$ADMIN_HOST:$ADMIN_PORT/consumers/myConsumer/basic-auth --data "username=httpbin" --data "password=httpbinPass"
curl -X POST http://$ADMIN_HOST:$ADMIN_PORT/consumers/anotherConsumer/basic-auth --data "username=anotherUsername" --data "password=anotherPass"
curl -i -X GET   --url http://$ADMIN_HOST:$PROXY_PORT/httpbin   --header "Host: kong"   --header "apikey: httpbinKey" -H 'Authorization: Basic aHR0cGJpbjpodHRwYmluUGFzcw=='
curl -i -X GET   --url http://$ADMIN_HOST:$PROXY_PORT/httpbin   --header "Host: kong"   --header "apikey: anotherKey" -H 'Authorization: Basic YW5vdGhlclVzZXJuYW1lOmFub3RoZXJQYXNz'

curl -X POST http://$ADMIN_HOST:$ADMIN_PORT/services/combined/plugins --data 'name=rate-limiting' --data "config.second=1" --data "config.hour=10000"
curl -i -X GET   --url http://$ADMIN_HOST:$PROXY_PORT/httpbin   --header "Host: kong"   --header "apikey: httpbinKey" -H 'Authorization: Basic aHR0cGJpbjpodHRwYmluUGFzcw=='
curl -i -X GET   --url http://$ADMIN_HOST:$PROXY_PORT/httpbin   --header "Host: kong"   --header "apikey: httpbinKey" -H 'Authorization: Basic aHR0cGJpbjpodHRwYmluUGFzcw=='
curl -i -X GET   --url http://$ADMIN_HOST:$PROXY_PORT/httpbin   --header "Host: kong"   --header "apikey: httpbinKey" -H 'Authorization: Basic aHR0cGJpbjpodHRwYmluUGFzcw=='

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/httpbin> (host kong)\n"
