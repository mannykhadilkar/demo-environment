#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=aws-lambda paths:='["/awsLambda"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=aws-lambda config.aws_key=AKIAISI6KUSKNVBQFNGA config.aws_region=us-east-2 config.aws_secret='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' config.function_name=kongDemo config.log_type=Tail

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/awsLambda>\n"
