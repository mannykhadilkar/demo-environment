#!/bin/sh
if [ "$ENABLE_ENABLE_OPENLDAP" = true ] ; 
then
  ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=ldap paths:='["/ldap"]' | jq -r '.id' )

  http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=ldap-auth-advanced config.ldap_host=ldap config.ldap_port=389 config.base_dn=ou=people,dc=apim,dc=eu config.header_type=ldap config.attribute=cn config.verify_ldap_host=false config.hide_credentials=true
  http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=demo

  export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/ldap> (username demo, password KongRul3z! - base64 encoded header for this looks like 'Authorization:LDAP ZGVtbzpLb25nUnVsM3oh')\n"
fi