#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oidc-auth0 paths:='["/oidcAuth0"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=sven@konghq.com custom_id=sven@konghq.com

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=openid-connect \
config.issuer=https://svenwal.eu.auth0.com/.well-known/openid-configuration \
config.client_id=WBEAcJvWn45v43zsKUVn7vmf8XVm0o55 \
config.client_secret=HcQ2zWySkHX3WeR6Gl7YzB0FYPCJFwXd5euaJ5T-TlCSoVFxIxMe2jhTFRcOwOkB \
config.ssl_verify=false \
config.consumer_claim=email \
config.verify_signature=false \
config.redirect_uri=http://$PROXY_HOST:$PROXY_PORT/oidcAuth0

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oidcAuth0>  Auth0-user demo@apim.eu, Auth0-password KongRul3z!\n"
