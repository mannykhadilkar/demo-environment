#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=login-form paths:='["/loginForm"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=request-termination config.content_type="text/html" config.status_code=200 config.body=@subScripts/loginForm.html

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/loginForm> (open in browser, uses the /basicAuth endpoint)\n"
