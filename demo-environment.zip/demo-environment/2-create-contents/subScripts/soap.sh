#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services name=soap-service url=http://www.dneonline.com/calculator.asmx
http -f $ADMIN_HOST:$ADMIN_PORT/services/soap-service/routes name=soap-route paths=/soap

http -f $ADMIN_HOST:$ADMIN_PORT/routes/soap-route/plugins name=rate-limiting config.second=1 config.minute=5 config.hour=100

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/soap> Kong proxies SOAP. Simply pass in a SOAP body using Content-Type:text/xml \`echo '<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\"> <soapenv:Header/> <soapenv:Body> <tem:Add> <tem:intA>5</tem:intA> <tem:intB>2</tem:intB> </tem:Add> </soapenv:Body> </soapenv:Envelope>' | http $PROXY_HOST:$PROXY_PORT/soap content-type:text/xml\`\n"
