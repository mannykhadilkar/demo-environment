#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oidc-cognito paths="/oidcCognito"

http -f $ADMIN_HOST:$ADMIN_PORT/routes/oidc-cognito/plugins name=openid-connect \
config.issuer=https://cognito-idp.us-west-2.amazonaws.com/us-west-2_nBkzSURlq \
config.client_id=3d5vpd0to0l9dns20f24hkao32 \
config.client_secret=1lqehi90ki4tmdep771o8bfe79rop62ad3ick6momigm989k81no \
config.redirect_uri=http://$PROXY_HOST:$PROXY_PORT/oidcCognito

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oidcCognito> AWS Cognito user demo@apim.eu / KongRul3z!\n"
