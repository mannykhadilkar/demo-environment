
# JWT usage details

* Go to the <https://jwt.io/>
* On the right hand side (Decoded) add a new header entry with the JWT key of the consumer (either look at the consumer or the [demo-services](/demo-services) page) in the to be added entry "iss".

Header now should look similar to

`{ "alg":"HS256",  "typ":"JWT",  "iss":"JWT_KEY_OF_CONSUMER"}`

* Now also on the right hand side there is a section called "Verify signature" with a textbox to enter the secret (placeholder text is something like `your-256-bit-secret`). Paste the JWT secret of the consumer in here
* When having done that copy the encoded token (left side on jwt.io) and use it as described as a header like for example `http localhost:8000/jwt 'Authorization:Bearer THE_COPIED_ENCODED_TOKEN'`