-- This example showcases an imagined situation where we want to customize all
-- consumer facing kong errors into a particular syntax.
-- Maybe we have a legacy system that expects errors to have a certain
-- structure.

-- a map of kong messages to match with a custom message and status
local error_map = {
  -- Default
  [0] = function (status, body, headers) return {
    message = body.message,
    _type = "KONG_ERROR",
  } end,
  ["No API key found in request"] = {
    message = "SO VERY. MUCH WRONG: API KEY NOT HERE",
  },
  ["Invalid authentication credentials"] = {
    message = "CONFUSE. BAD API CREDENTIALS!",
    status = 403,
    _type = "ANOTHER_KIND_OF_ERROR",
  },
}


return function (status, body, headers)
  -- maybe try to get a better way if response comes from kong or not
  if not body or not body.message then
    return status, body, headers
  end

  -- Direct error match or default error
  local error = error_map[body.message] or error_map[0](status, body, headers)

  body = {
    resultType = "ERROR",
    error = {
      ["errorType"] = error._type or "KONG_ERROR",
      ["errorCode"] = error.status or status,
      ["apiMessage"] = error.message or body.message,
      ["errors"] = { body.message }
    },
    -- A function called request_id is available to this function context
    ["requestId"] = request_id(),
  }

  status = error.status or status
  headers = error.headers or headers

  return status, body, headers
end
