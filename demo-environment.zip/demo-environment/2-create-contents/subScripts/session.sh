#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=ldap-session paths:='["/session"]' | jq -r '.id' )

ANON_USER=$(http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=anonymous_session_user | jq -r '.id' )
http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=key-auth config.anonymous=$ANON_USER
http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins "name=request-termination" "config.status_code=403" "config.message=Neither api key nor valid session found" "consumer.id=$ANON_USER"

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=session config.cookie_secure=false

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/session> First call with a valid api key (for example silver) \`http $PROXY_HOST:$PROXY_PORT/session apikey:silver\`<br />This call returns a Set-Cookie header, use it as follows \`http $PROXY_HOST:$PROXY_PORT/session 'cookie:session=YOUR_SESSION_KEY'\`\n"
