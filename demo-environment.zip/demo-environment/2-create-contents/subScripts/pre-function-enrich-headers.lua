return function()
  local custom_header = kong.request.get_header('x-uuid')

  if not custom_header then
    local http = require "resty.http"
    local httpc = http.new()
    local res, err = httpc:request_uri("http://httpbin.org/uuid", {
      method = "GET",
      headers = {
        ["My-header-to-external"] = "hello",
      },
      keepalive_timeout = 60,
      keepalive_pool = 10
    })
    if not res then
      return kong.response.exit(401, 'Invalid credentials')
    end

    local cjson = require("cjson.safe").new()

    local serialized_content, err = cjson.decode(res.body)
    if not serialized_content then
      return kong.response.exit(401, 'Invalid credentials')
    end

    kong.service.request.add_header('x-uuid', serialized_content.uuid)
  end
end