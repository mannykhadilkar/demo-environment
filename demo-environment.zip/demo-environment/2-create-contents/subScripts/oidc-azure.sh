#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oidc-azure paths:='["/oidcAzure"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=sven@walther.world custom_id=sven@walther.world

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=openid-connect \
config.issuer=https://login.microsoftonline.com/svenwalther.onmicrosoft.com/.well-known/openid-configuration \
config.client_id="d833979b-b2e4-4dc3-a601-4ebf74a8f7ec" \
config.client_secret="0DBrY0leKTZleAryQXdb7%2Bdj4nTe3UlnaobkJ75Emnw%3D" \
config.ssl_verify=false \
config.consumer_claim=email \
config.verify_signature=false \
config.redirect_uri=http://$PROXY_HOST:$PROXY_PORT/oidcAzure

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oidcAzure>  Azure ID user demo@apim.eu / 2K4yt28Q{;rMoR>dY[mGoZa\n"
