#!/bin/sh
ROUTE_ID_TRANSFORM=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=request-transformer-advanced paths='/transformerAdvanced/(?<some_id>\w+)' -f | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID_TRANSFORM/plugins name=request-transformer-advanced config.add.querystring="idAsQueryString:\$(uri_captures['some_id'])" config.append.headers="myUserId:\$(uri_captures['some_id'])" config.replace.uri="/anything/myService/users/\$(headers['specialHeader'])"

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/transformerAdvanced> Will pick up an URI parameter as well as a header and inject it in other locations - try http http://$PROXY_HOST:$PROXY_PORT/transformerAdvanced/myUserId specialHeader:thisIsMySentHeader\n"
