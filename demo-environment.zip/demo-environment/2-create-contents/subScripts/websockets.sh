#Creating Services
http $ADMIN_HOST:$ADMIN_PORT/services name=secure-websocket-service url=https://demos.kaazing.com/echo
http $ADMIN_HOST:$ADMIN_PORT/services name=websocket-service url=http://demos.kaazing.com/echo

#Creating Routes
http $ADMIN_HOST:$ADMIN_PORT/services/secure-websocket-service/routes name=secure-websocket-route paths:='["/secure-websocket"]' protocols:='["https"]'
http $ADMIN_HOST:$ADMIN_PORT/services/websocket-service/routes name=websocket-route paths:='["/websocket"]' protocols:='["http"]'
