#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=oidc-okta paths:='["/oidcOkta"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=openid-connect \
config.issuer=https://dev-841896-admin.okta.com/oauth2/default/.well-known/openid-configuration \
config.client_id=0oapertl8nQG3uGdU356 \
config.client_secret=kz5Fbeo1-Y-tnnT3UeLbKugU5llC8qkcK9KTzLVq \
config.redirect_uri=http://$PROXY_HOST:$PROXY_PORT/oidcOkta

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/oidcOkta> (demo@apim.eu / KongRul3z!)\n"
