#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=gold-silver-free paths:='["/goldSilverFree"]' | jq -r '.id' )
ROUTE_ID_REDIS=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=gold-silver-free-redis paths:='["/goldSilverFreeRedis"]' | jq -r '.id' )

KEY_AUTH_PLUGIN_ID=$(http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=key-auth config.key_names=apikey | jq -r '.id' )
KEY_AUTH_PLUGIN_ID_REDIS=$(http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID_REDIS/plugins name=key-auth config.key_names=apikey | jq -r '.id' )
http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=rate-limiting-advanced config.limit=3 config.sync_rate=10 config.window_size=60
http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID_REDIS/plugins name=rate-limiting-advanced config.limit=3 config.sync_rate=10 config.window_size=60 config.strategy=redis config.redis.host=redis config.redis.port=6379 config.redis.password=kong config.redis.database=1

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=gold-partner
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/gold-partner/key-auth key=gold
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/gold-partner/plugins name=rate-limiting-advanced config.limit=25 config.sync_rate=10 config.window_size=60 route.id=$ROUTE_ID
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/gold-partner/plugins name=rate-limiting-advanced config.limit=25 config.sync_rate=10 config.window_size=60 route.id=$ROUTE_ID_REDIS config.strategy=redis config.redis.host=redis config.redis.port=6379 config.redis.password=kong config.redis.database=1

http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=silver-partner
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/silver-partner/key-auth key=silver
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/silver-partner/plugins name=rate-limiting-advanced config.limit=10 config.sync_rate=10 config.window_size=60 route.id=$ROUTE_ID
http -f $ADMIN_HOST:$ADMIN_PORT/consumers/silver-partner/plugins name=rate-limiting-advanced config.limit=25 config.sync_rate=10 config.window_size=60 route.id=$ROUTE_ID_REDIS config.strategy=redis config.redis.host=redis config.redis.port=6379 config.redis.password=kong config.redis.database=1

FREE_USER_ID=$(http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=free | jq -r '.id' )
http -f PATCH $ADMIN_HOST:$ADMIN_PORT/plugins/$KEY_AUTH_PLUGIN_ID config.anonymous=$FREE_USER_ID
http -f PATCH $ADMIN_HOST:$ADMIN_PORT/plugins/$KEY_AUTH_PLUGIN_ID_REDIS config.anonymous=$FREE_USER_ID

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/goldSilverFree> (apikeys gold, silver, NONE=anonymous)\n"
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/goldSilverFreeRedis> (apikeys gold, silver, NONE=anonymous)\n"
