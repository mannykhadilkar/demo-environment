#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=jwt paths:='["/jwt"]' | jq -r '.id' )

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=jwt
JWT_USER=$(http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=jwt-user custom_id=jwt-user | jq -r '.id' )
JWT_KEY=$(http POST $ADMIN_HOST:$ADMIN_PORT/consumers/jwt-user/jwt | jq -r '.key' )
JWT_SECRET=$(http $ADMIN_HOST:$ADMIN_PORT/consumers/jwt-user/jwt | jq -r '.data[0].secret' )

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/jwt> Key (iss) \`$JWT_KEY\`, Secret \`$JWT_SECRET\` See [this page](/jwt) for more details\n"
cp ./subScripts/jwt.md $PAGES_FOLDER