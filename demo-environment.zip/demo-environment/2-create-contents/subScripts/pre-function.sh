#!/bin/sh
http -f $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=pre-function paths="/preFunctionAuth"
http -f $ADMIN_HOST:$ADMIN_PORT/routes/pre-function/plugins name=pre-function config.functions=@./subScripts/pre-function-auth.lua
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/preFunctionAuth> this function will deny access if there is not header called x-custom-auth in the request\n"
