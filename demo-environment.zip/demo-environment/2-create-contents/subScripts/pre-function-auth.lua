return function()
  local custom_auth = kong.request.get_header('x-custom-auth')

  if not custom_auth then
    return kong.response.exit(401, 'Invalid credentials')
  end

  kong.service.request.clear_header('x-custom-auth')
end
