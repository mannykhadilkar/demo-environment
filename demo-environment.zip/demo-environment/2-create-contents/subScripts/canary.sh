#!/bin/sh
ROUTE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/httpbin/routes name=canary paths:='["/canary"]' | jq -r '.id' )

#http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=canary config.hash=none config.duration=86400 config.start=`date -v +10S +%s` config.steps=5 config.upstream_host=placeholder config.upstream_port=3000 config.upstream_uri=/albums config.percentage=20

http -f $ADMIN_HOST:$ADMIN_PORT/routes/$ROUTE_ID/plugins name=canary config.hash=none config.steps=3600 config.upstream_host=placeholder config.upstream_port=3000 config.upstream_uri=/albums config.percentage=50

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/canary>\n"
