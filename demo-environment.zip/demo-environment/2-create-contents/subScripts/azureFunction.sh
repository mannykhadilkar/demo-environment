#!/bin/sh
http $ADMIN_HOST:$ADMIN_PORT/services/serverless/routes name=azure-function paths:='["/azureFunction"]'

http -f $ADMIN_HOST:$ADMIN_PORT/routes/azure-function/plugins name=azure-functions config.apikey="Q4xpHz0d8gxUq7WRq6KS8gdLmE2EEcJ6QwhktdzgPEMUzfCKOkRFaA==" config.appname=kong-demo config.clientid=kong-se-demo config.functionname=HttpTrigger1 

export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <http://$PROXY_HOST:$PROXY_PORT/azureFunction> Send query parameter name=Something to get a valid response\n"
