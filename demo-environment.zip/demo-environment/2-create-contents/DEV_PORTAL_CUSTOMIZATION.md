# Developer portal customization
The createContents.sh will change the default developer portal in some places.

## Demo services
A new page is added to the authenticated section of the portal called "Demo-Services" which lists all created services. It is also linked in the authenticated navigation bar.

## Design settings overview
You can change the many design details of you dev portal by setting some environment variables. The following parameters are available:

* PORTAL_THEME: will have many effects on design as well as created workspaces and services. A list of the available design can be found by looking into the 2-create-contents/subScripts/themes folder - each shell script here is a theme. For example of there is a script called "myCoolTheme.sh" in this folder you can set PORTAL_THEME to "myCoolTheme" to use it. Some of those might overwrite the below settings automatically
* THEME_HEADER_COLOR: A value (like "red" or "#000") which will be used to change the background color of the header.
* THEME_LOGO_DATA: A data uri value to exchange the logo on the top left. See below for more details
* THEME_LOGO_URL: A link to an external image to be used as logo. THEME_LOGO_DATA will be ignored if this parameter is used
* THEME_WELCOME_TITLE: The title to be shown on the dev portal homepage (default is "Build with Kong")
* THEME_WELCOME_TEXT: The text on the homepage (after the title)
* THEME_WELCOME_BACKGROUND_TEXT_BOX: if set to any value the title, text and the graphic on right of those are getting a dark, semitransparent background. This is very helpful when using a background image (see below) or a light backgroud color
* THEME_WELCOME_BACKGROUND_COLOR: The background color of the welcome text area (dark blue by default). Will be ignored if a background image is specified
* THEME_WELCOME_BACKGROUND_IMAGE_URL: A url pointing to any image which should be used as background of the homepage (the area which for the title and welcome text and being dark blue by default). This image needs to be accessible by this url, it is not a data uri (like THEME_LOGO_DATA) and might be hosted somewhere on a webserver. The image will be strectched to full width so do not use a small one
* THEME_CUSTOM_CSS: CSS entries like `````h1 { color:red }````` which can be used to tweak any css on the dev portal. You can also use a file to store such settings - see below
* THEME_WORKSPACE: use this if the portal theming should not be done on default workspace. Your scripts must create this workspace and have the portal enabled on that workspace for this to work
* THEME_HOMEPAGE_COMPANIES: A space seperated list of company names you want to have listed on the dev portal homeage in the section "You're in good company"

![Example screenshot](../screenshots/DeveloperPortalCustomization.jpg)

Find an example script at the demo-environment root folder called demo-settings.sh for examples

## Design settings details

To exchange the logo automatically by providing the image data in an environment variable called THEME_LOGO_DATA (do not miss quotation marks). The value needs to be the already converted image ("data:image....") - you can use <https://ezgif.com/image-to-datauri> to create the data (note the dropdown "Include tags for" should be "Nothing on second page").
Hint: the original image is 232px*32px

`````export LOGO_DATA="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAAAgCAYAAAAYEjShAAABfGlDQ1BJQ0MgcHJvZmlsZQAAKJFjYGAqSSwoyGFhYGDIzSspCnJ3UoiIjFJgv8PAzcDDIMRgxSCemFxc4BgQ4MOAE3y7xsAIoi/rgsxK8/x506a1fP4WNq+ZclYlOrj1gQF3SmpxMgMDIweQnZxSnJwLZOcA2TrJBUUlQPYMIFu3vKQAxD4BZIsUAR0IZN8BsdMh7A8gdhKYzcQCVhMS5AxkSwDZAkkQtgaInQ5hW4DYyRmJKUC2B8guiBvAgNPDRcHcwFLXkYC7SQa5OaUwO0ChxZOaFxoMcgcQyzB4MLgwKDCYMxgwWDLoMjiWpFaUgBQ65xdUFmWmZ5QoOAJDNlXBOT+3oLQktUhHwTMvWU9HwcjA0ACkDhRnEKM/B4FNZxQ7jxDLX8jAYKnMwMDcgxBLmsbAsH0PA4PEKYSYyjwGBn5rBoZt5woSixLhDmf8xkKIX5xmbARh8zgxMLDe+///sxoDA/skBoa/E////73o//+/i4H2A+PsQA4AJHdp4DTXElsAAAAGYktHRAAAADQAWciWH2MAAAAJcEhZcwAALiMAAC4jAXilP3YAAAAHdElNRQfjBgQMNR96BZdcAAAAGXRFWHRDb21tZW50AENyZWF0ZWQgd2l0aCBHSU1QV4EOFwAABbpJREFUeNrtnH9oVWUYx59z76a4rTB/DhJdRiDOUCsicllNaAQNJEHoj4J+zbAfREmMwP5JHGqY+o8KlhESmOgWRglBkiMctqWhJi5CW5nb3I+7e+49O+95n/d5+qP3yNtl855kOpnP56/Dud/7cnje+73f57zvuRfgJuH7/nRE3KWUegEEQbg1WLNmTRoR3yKiAWZmIurOZrMVUhlBGGfCMKwlorNcACJulOoIwjiRy+XmG2MO8igQUZDNZu+RSgnCOICIu7gIiLhfKiUI42PQGUQ0VMykURQ9JtUShPEx6TvFDGqMOSWVEoSbRBAES5RSSwEAzp49O5mIzhczqdb6JamcINxAfN+fiYh7bCqeiM+HYbiymEGJqEe2XQThBnDq1KlJiLiOmf2CVLz6MIIx5vsEC0abpJqCMIYopepHa2GJ6G9jTJnVLeLiDPu+f69UVRDGAET8KMG95QZHvztBih6QygrCGBAEwZIEqZjPZDLzAAByudwMIsomMPXjUl1BGAOMMZ8k2Eb5wknRdxPof2loaPCkuoJwHWSz2Tm+708FAPB9fzYR5YreXA4PLwMA6OrqmkxEnQlS9FWptCD8DwYGBqZorT9g5pwx5uP4vNa6MUEqdsR6pdSzCbZden3fv0OqLggJiKJotTHmomMgjYgL7L3lFGPM7wlS8UWnNT6awNRbpPKCcA2UUvcbY34YZcX1G9fACVKxWylVHo9LRFREH4ZheJ/MgiCMgNb6w2KmU0rVOanYmiBFNzoLRkm2XQ7JTAjCyG1tQ4JU/LWpqSkFADA8PLw0gX44/g1oFEUzE/7a5QmZDUEYAWPM6QSp+KaTip8muLf80tGvS6A/XVVVJdsugnA99Pf3P8XMHATBV0qpV6yvdl/rPdbYg1I9QShOSkogCLcuJU5LW6a1XsbM00pLS9vS6XQeAOYhYm9paemfAAB1dXVeS0tLTSqVqgKAjlwu547VAgAnAaDPPamUqvY87wFjzIUVK1b8ONJF5PP5+el0+hEAuNzZ2Xm8urp6YSqV8jzP67D3rGXGmEc9z6tMpVIdkyZNOidTJ9w2RFG0moj6C+7/frPt6HYAAK11TeGeJyJeGK3F1VrPLdymMcZ0ui1uFEXliNhSuCUTb8MAABDR8sJrI6IjRFQmMydMePL5fA0zk/3gHwjDcFtsztigQRDMZ+acNeV3VtMeawoN2tzcXBIvMhHRGas/7Iw5aFP7W2vcrjAMtxtj9sfX4hi0y77neSJ6iIgO2W2e9TJ7woSHiI7YLY3X3XaXiM7FBtVa77CarbGmsbExhYhHRjIoIq6y5uzo6emZ4oy7PjaoUupha84/Ll26NNVJ89cKDGqsbpPWuqavr29RFEXPBEGwWGZPmPAYY/JERLW1tV7B+fdigzLzT9agC1xNGIarRzHoDmuqta6+t7d3WmxQZm6wms2upr6+3nNb3CiK9o7wEEPr0NDQQpk9YaKTAoABz/O8w4cPT3NfYOa7nZTN2sNZ/1lhKimZPcq4A3aM6e7J8vLyOfExIip7WOlq9u3bd5fneVe/LNra2l5WSj1HRJ8z888AYNLpdE1FRcVBmT7hdlgg2mlT7Uh3d/dUm55PM3M+TlAiejv+Q7ChoaG5AABBECwmor9GStBMJvOgbXH9IAietPrZzHwsTlCt9SxmHiaiSCm1EgDgypUrd0ZR9LXzJNF8Zm5HxGMbNmwosYtPy+3YRmZPuB0WiWYw88X4Q4+IgwVPC20/c+bMZCJqdYzT52pGWsUlom2Ovr9gzEFrtjectnWQiNDV2S+Lk/baWqMoaiKiDqtvltkTbgt8368kor1ElKF/OU5EO5m5XWu9zhquDBG3ENFlm6bnwjDcwcztQRBsVUqtZOZ2Zn7faWPXGmPOx38khoib7ZhHHc0qRGy3Y/ZprXcbY04wc7tN1Uoi+swY0281PYi4J5PJyG9GhQnPP53dNZ1DgtbkAAAAAElFTkSuQmCC"`````

## CSS changes
Last but not least you can create a file at `~/.demo-env/dev_portal_custom.css` or use the environment variable THEME_CUSTOM_CSS to add any CSS to the dev portal
Any content of this file / environment variable will be added with no checks so make sure it's valid CSS. 

Example

`````h1 { color:red }`````
