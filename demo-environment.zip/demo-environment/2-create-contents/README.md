# Create content
These scripts are filling up the demo system with all contents

Execute the ````./createContents.sh [interactive]```` script. Services, routes, plugins, workspaces and more will be created. The final output of the script is a list of created routes. If the optional parameter "interactive" is provided scripts may ask for details to overwrite defaults (for example usernames and passwords)

## Adding new subScript
You can really help us all out! Please do so by creating a new script in the subScripts folder per plugin/use-case. Create your own branch and submit a PR against master, clearly documenting the addition and any technical details you think will clarify the subScript's usage.

Make sure the contents of the script are independent from any other script in this folder (i.e. uniquely named /route). A generic service /services/httpbin may be used - but do not apply any plugins to the base service. Instead, only apply a plugin demo to routes. This avoids conflicts because routes are the most fine-grained object available in Kong and is the intention behind their design. Services are handy in non-demo environments when "grouping" behavior (i.e. applying a rate-limit to an entire service and its complete set of endpoints) is desired.

Each script shall add an output to the provided env variable (see last line of examples) so when generator is run all available endpoints are listed.

Use an already existing script as template. If your script benefits from being interactive, please see the portal.sh for an example.
