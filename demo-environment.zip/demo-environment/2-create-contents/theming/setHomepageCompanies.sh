#!/bin/sh
boxes=""
if [ "$THEME_HOMEPAGE_COMPANIES" != "" ];
then
  echo "Adding companies based on \$THEME_HOMEPAGE_COMPANIES"
  list=${list:-$THEME_HOMEPAGE_COMPANIES}
  companies=(`echo ${list}`);
  for company in "${companies[@]}"; do
    boxes="$boxes <a class=\"client\">$company<\/a>"
  done
else
  # Adding all workspace names to portal homepage
  echo "Adding companies based on workspaces"
  WORKSPACES=$(http $ADMIN_HOST:$ADMIN_PORT/workspaces | jq -r '.data[].name')
  for WORKSPACE in $WORKSPACES; do
    if [ ! "$WORKSPACE" = "default" ]; then
      boxes="$boxes <a class=\"client\">$WORKSPACE<\/a>" 
    fi
  done
fi

if [ "$boxes" != "" ];
then
  cp theming/client_template.html clients.html
  sed -i -E "s/ENTRIES_PLACEHOLDER/$boxes/g" clients.html
  http PATCH http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/partials/homepage/clients.html contents=@clients.html
  rm clients.html
  rm clients.html-E
fi
