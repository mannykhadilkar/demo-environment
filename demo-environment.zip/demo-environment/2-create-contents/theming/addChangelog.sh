#!/bin/sh
cp ../CHANGELOG.md $PAGES_FOLDER/changelog.md
