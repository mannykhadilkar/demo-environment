#!/bin/sh
# header - nav
http http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/partials/header.html | jq -r '.contents' > header.html
sed -i -E 's/<li class="has-dropdown">/<li class="has-dropdown"><a href="demo-services">Demo System<\/a><ul class="dropdown" aria-label="submenu"> <li><a href="demo-services">Demo-Services<\/a><\/li> <li><a href="changelog">Changelog<\/a><\/li><li><a href="deprecated">Deprecation Policy<\/a><\/li><\/ul><\/li><li class="has-dropdown">/g' header.html
http PATCH http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/partials/header.html contents=@header.html
rm header.html
rm header.html-E
