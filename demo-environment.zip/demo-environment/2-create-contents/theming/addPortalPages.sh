#!/bin/sh
PAGES_FOLDER=~/.demo-env/portalPages
echo "Adding custom pages to the developer portal"
if [ -d "$PAGES_FOLDER" ]
then
  pages=( $(find $PAGES_FOLDER/*.md -type f ) )
  for pagePath in ${pages[@]}; do 
    page=$( echo "$pagePath" | xargs basename | sed 's/\.md//g' )
    echo "* Adding page $page.md to the dev portal"
    cp ./devPortalPage.header ./temp.md
    echo "---" > ./temp.md
    echo "layout: markdown_page.html" >> ./temp.md
    echo "---" >> ./temp.md
    echo "" >> ./temp.md
    cat $PAGES_FOLDER/$page.md >> temp.md
    http $ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files path=content/$page/index.md contents=@temp.md
    rm temp.md
  done
fi
