#!/bin/sh
# demo services

echo "# Demo services\n" > $PAGES_FOLDER/demo-services.md
echo "The following demo services have been automatically deployed by scripts using the admin API\n" >> $PAGES_FOLDER/demo-services.md
echo "$LIST_OF_PLUGINS" >> $PAGES_FOLDER/demo-services.md

if [ "$DEMO_ENV" = "docker-compose" ]
then
  echo "# Monitoring\n" >> $PAGES_FOLDER/demo-services.md
  if [ "$ENABLE_PROMETHEUS_GRAFANA" = true ] ;
  then
    echo "* Grafana <http://$ADMIN_HOST:10100> (admin/admin)"  >> $PAGES_FOLDER/demo-services.md
    echo "* Syslog  <http://$ADMIN_HOST:10200> (kong/kong)"  >> $PAGES_FOLDER/demo-services.md
  fi
  if [ "$ENABLE_ELK" = true ]
  then
    echo "* Kibana  <http://$KIBANA_HOST:$KIBANA_PORT>"  >> $PAGES_FOLDER/demo-services.md
  fi
fi

echo "\n\nThis page has been generated automatically by the deployment script using the portal files API including the updated navigation" >> $PAGES_FOLDER/demo-services.md
