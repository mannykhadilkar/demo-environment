#!/bin/sh
echo "Reading current theme"

if [ ! -z "${THEME_WORKSPACE}" ]; then
  WORKSPACE_PREFIX="/$THEME_WORKSPACE"
fi

http http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/theme.conf.yaml | jq -r '.contents' > theme.conf.yaml

if [ ! -z "$THEME_MAIN_COLOR" ]
then
  yq w -i theme.conf.yaml colors.hero.value "$THEME_MAIN_COLOR"
  yq w -i theme.conf.yaml colors.accent.value "$THEME_MAIN_COLOR"
  yq w -i theme.conf.yaml colors.footer.value "$THEME_MAIN_COLOR"
fi

if [ ! -z "$THEME_BACKGROUND_COLOR" ]
then
  yq w -i theme.conf.yaml colors.page.value "$THEME_BACKGROUND_COLOR"
fi

if [ ! -z "$THEME_HEADER_COLOR" ]
then
  yq w -i theme.conf.yaml colors.header.value "$THEME_HEADER_COLOR"
fi

if [ ! -z "$THEME_WELCOME_BACKGROUND_COLOR" ]
then
  yq w -i theme.conf.yaml colors.hero.value "$THEME_WELCOME_BACKGROUND_COLOR"
fi

if [ ! -z "$THEME_BUTTON_BACKGROUND" ]
then
  yq w -i theme.conf.yaml colors.button_primary_fill.value "$THEME_BUTTON_BACKGROUND"
  yq w -i theme.conf.yaml colors.button_primary_fill_hover.value "$THEME_BUTTON_BACKGROUND"
  yq w -i theme.conf.yaml colors.button_secondary_fill.value "$THEME_BUTTON_BACKGROUND"
  yq w -i theme.conf.yaml colors.button_secondary_fill_hover.value "$THEME_BUTTON_BACKGROUND"
  yq w -i theme.conf.yaml colors.button_secondary_border.value "$THEME_BUTTON_BACKGROUND"
fi

if [ ! -z "$THEME_BUTTON_FOREGROUND" ]
then
  yq w -i theme.conf.yaml colors.button_primary_text.value "$THEME_BUTTON_FOREGROUND"
  yq w -i theme.conf.yaml colors.button_secondary_text.value "$THEME_BUTTON_FOREGROUND"
fi

if [ ! -z "$THEME_H1_COLOR" ]
then
  yq w -i theme.conf.yaml colors.text_headings.value "$THEME_H1_COLOR"
fi


if [ ! -z "$THEME_LOGO_URL" ]
then
  yq w -i theme.conf.yaml images.logo "$THEME_LOGO_URL"
else
  if [ ! -z "$THEME_LOGO_DATA" ]
  then
    IMAGE_NAME="$(uuidgen).png"
    echo $IMAGE_NAME
    http OPTIONS http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/assets/images/$IMAGE_NAME Access-Control-Request-Headers:content-type Access-Control-Request-Method:PUT
    http PUT http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/assets/images/$IMAGE_NAME path=themes/base/assets/images/$IMAGE_NAME contents="$THEME_LOGO_DATA"
    yq w -i theme.conf.yaml images.logo "assets/images/$IMAGE_NAME"
  fi
fi
http PATCH http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/theme.conf.yaml contents=@theme.conf.yaml
rm theme.conf.yaml


# Text on homepage

if [ -z "${THEME_WELCOME_TITLE}" ] && [ -z "${THEME_WELCOME_TEXT}" ] ; then
  echo "No custom homepage data found"
else
  cp theming/homepage_template.txt homepage.yaml
  if [ ! -z "${THEME_WELCOME_TITLE}" ]; then
    yq w -i homepage.yaml hero.title "$THEME_WELCOME_TITLE"
  fi
  if [ ! -z "${THEME_WELCOME_TEXT}" ]; then
    yq w -i homepage.yaml hero.tagline "$THEME_WELCOME_TEXT"
  fi
  echo "---" > index.txt
  cat homepage.yaml >> index.txt
  echo "---" >> index.txt
  http PATCH http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/content/index.txt contents=@index.txt
  rm index.txt
  rm homepage.yaml
fi

# CSS patching

http http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/assets/styles/site.css | jq -r '.contents' > site.css
CSS_CHANGED=FALSE

if [ -f ~/.demo-env/.demo-env/dev_portal_custom.css ]; then
  echo "Found ~/dev_portal_custom.css - adding css to dev portal\n"
  cat ~/.demo-env/dev_portal_custom.css >> site.css
  CSS_CHANGED=true
fi


if [ ! -z "$THEME_WELCOME_BACKGROUND_IMAGE_URL" ]
then
  echo "\n.homepage-hero { background-image:url($THEME_WELCOME_BACKGROUND_IMAGE_URL) !important; background-size: cover;}\n" >> site.css
  CSS_CHANGED=true
fi

if [ ! -z "$THEME_HEADER_LINK_COLOR" ]
then
  echo "\n.site-header nav li a:not(.nav-button) { color: $THEME_HEADER_LINK_COLOR !important}\n" >> site.css
  CSS_CHANGED=true
fi

if [ "$THEME_WELCOME_BACKGROUND_TEXT_BOX" = true ]
then
  echo "\ndiv.hero-header { background-color: rgba(0, 0, 0, 0.6);padding: 1em;border-radius: 8px;margin:2em; width:50em; margin: auto }\n" >> site.css
  CSS_CHANGED=true
fi

if [ ! -z "${THEME_CUSTOM_CSS}" ]; then
  echo $THEME_CUSTOM_CSS >> site.css
  CSS_CHANGED=true
fi 

if [ "${CSS_CHANGED}" = "true" ]; then
  http PATCH http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/assets/styles/site.css contents=@site.css
fi  
rm ./site.css
