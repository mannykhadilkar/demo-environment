#!/bin/sh
echo "mTLS certificates creation"
echo "Only run from the 2-create-contents folder like ./helpers/createTlsCertificates.sh and not ./createTlsCertificates.sh"
INIT_DIR=$PWD
cd helpers
CERT_FOLDER=~/.demo-env/certificates
ROOT_CA_FOLDER=$CERT_FOLDER/mTLSbackend/ca
CLIENT_CERT_FOLDER=$CERT_FOLDER/mTLSbackend/client

if [ ! -d "$CERT_FOLDER" ] 
then
  mkdir -p $CERT_FOLDER
fi

echo "Creating root CA"
if [ ! -d "$ROOT_CA_FOLDER" ]
then
  mkdir -p $ROOT_CA_FOLDER
  mkdir $ROOT_CA_FOLDER/certs
  mkdir $ROOT_CA_FOLDER/crl
  mkdir $CLIENT_CERT_FOLDER
  mkdir $ROOT_CA_FOLDER/private
  touch $ROOT_CA_FOLDER/index.txt
  echo 1337 > $ROOT_CA_FOLDER/serial
  chmod 700 $ROOT_CA_FOLDER/private
  cp ./openssl.cnf.template ./openssl.cnf
  sed -i -e "s|HOME_DIR|$HOME|g" ./openssl.cnf
  cp ./openssl.cnf $CERT_FOLDER/mTLSbackend/
  rm ./openssl.cnf
  rm ./openssl.cnf-e
fi

cd $ROOT_CA_FOLDER
openssl genrsa -aes256 -out private/ca.key.pem -passout pass:KongRul3z 4096
# openssl rsa -in private/ca.key.pem -out private/ca.key.decryted.pem -passin 'pass:KongRul3z'
chmod 400 private/ca.key.pem
openssl req -config $CERT_FOLDER/mTLSbackend/openssl.cnf -key private/ca.key.pem -new -x509 -days 7300 -sha256 -extensions v3_ca -passin 'pass:KongRul3z' -subj "/C=WD/ST=Earth/L=Global/O=Kong Inc./CN=Kong CA" -out certs/ca.cert.pem
chmod 444 certs/ca.cert.pem

echo "Creating the client certificate"
if [ ! -d "$CLIENT_CERT_FOLDER" ]
then
  mkdir -p $CLIENT_CERT_FOLDER
fi
cd $CLIENT_CERT_FOLDER/
openssl genrsa -out client.key 2028
openssl req -new -subj "/emailAddress=demo@apim.eu/CN=apim.eu/O=Kong Inc./OU=Solution Engineering/C=WD/ST=Earth/L=Global" -key client.key -out client.csr
openssl ca -batch -config $CERT_FOLDER/mTLSbackend/openssl.cnf -extensions usr_cert -cert ../ca/certs/ca.cert.pem -keyfile ../ca/private/ca.key.pem  -passin 'pass:KongRul3z' -in client.csr -out client.crt


# getting back to initial folder where this script has been invoked from
cd "$INIT_DIR"
