#!/bin/sh
echo "deleting mTLS certificates"
CERT_FOLDER=~/.demo-env/certificates

if [ -d "$CERT_FOLDER/mTLSbackend" ] 
then
  rm -Rf $CERT_FOLDER/mTLSbackend
fi