#!/bin/sh
if [ $# -lt "1" ]
then
  echo "Usage: ./createDataUriFromImage.sh imageFile [TARGET_FOLDER]"
  exit
fi 

FILE=$1

if [ -z "$2" ]; then
  TARGET_FOLDER=/tmp
else
  echo else
  if [ ! -d "$2" ]
  then
    echo then
    echo "Target folder not found, using /tmp instead" 
    TARGET_FOLDER=/tmp
  else
    TARGET_FOLDER=$2
    echo $TARGET_FOLDER
  fi
fi

if [ -f "$FILE" ]; then
  FILENAME=$(basename "$FILE")
  printf "data:image/png;base64," > $TARGET_FOLDER/$FILENAME.64
  base64 -i $FILE >> $TARGET_FOLDER/$FILENAME.64
  echo "Converted file saved at $TARGET_FOLDER/$FILENAME.64"
else
  echo "File not found"
fi

