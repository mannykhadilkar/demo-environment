#!/bin/sh
if [ ! -z "${THEME_WORKSPACE}" ]; then
  WORKSPACE_PREFIX="/$THEME_WORKSPACE"
fi

http POST $ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files path=themes/base/layouts/markdown_page.html contents=@theming/markdown_template.html



./theming/addDemoServices.sh 
./theming/addChangelog.sh 
./theming/addPortalPages.sh
./theming/updateNavigation.sh 
./theming/setHomepageCompanies.sh

http http://$ADMIN_HOST:$ADMIN_PORT$WORKSPACE_PREFIX/files/themes/base/theme.conf.yaml | jq -r '.contents' > theme.conf.yaml

./theming/patchTheme.sh
