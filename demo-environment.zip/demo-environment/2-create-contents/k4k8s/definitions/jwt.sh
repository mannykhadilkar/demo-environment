#!/bin/sh
kubectl apply -f jwt.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/jwt> Use <https://jwt.io> to generate a token with a header entry added \`iss:myJwtKey\` and the signature secret \`myJwtSecret\` Use the created token with \`http $k8s/jwt/anything 'Authorization:Bearer GENERATED_TOKEN'\`. See developer portal for my details \n"

