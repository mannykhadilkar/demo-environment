#!/bin/sh
kubectl apply -f pre-function-auth.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/preFunctionAuth> this function will deny access if there is not header called x-custom-auth in the request\n"

