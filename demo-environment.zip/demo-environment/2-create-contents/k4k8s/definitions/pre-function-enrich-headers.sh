#!/bin/sh
kubectl apply -f pre-function-enrich-headers.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/preFunctionEnrichHeaders> this function will look for a header called x-uuid - if it is not present it fetches one from <http://httpbin.org/uuid> and adds it to the backend call. Example for request enrichment with external source\n"

