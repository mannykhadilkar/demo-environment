#!/bin/sh
kubectl apply -f ./proxyCache.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/proxyCache>\n"
