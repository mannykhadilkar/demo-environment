#!/bin/sh
kubectl apply -f canary.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/canary>\n"

