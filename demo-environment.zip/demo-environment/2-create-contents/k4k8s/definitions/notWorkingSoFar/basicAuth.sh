#!/bin/sh
kubectl apply -f basicAuth.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/basicAuth> username basic, password auth\n"

