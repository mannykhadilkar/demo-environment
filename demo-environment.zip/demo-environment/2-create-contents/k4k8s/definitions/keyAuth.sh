#!/bin/sh
kubectl apply -f keyAuth.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/keyAuth> Keys are for example gold, silver or developer\n"

