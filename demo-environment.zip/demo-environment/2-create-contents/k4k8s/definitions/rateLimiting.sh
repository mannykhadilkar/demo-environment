#!/bin/sh
kubectl apply -f ./rateLimiting.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/rateLimiting> Note: uses Redis for counter storage\n"
