#!/bin/sh
for consumer in ./consumers/*.yaml; do 
  echo "********** Adding $consumer"
  kubectl apply -f $consumer
done
