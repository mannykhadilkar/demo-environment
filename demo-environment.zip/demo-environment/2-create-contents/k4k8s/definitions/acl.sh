#!/bin/sh
kubectl apply -f acl.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/acl> apikey allowed acl11, acl12 - disallowed acl21,acl22 (and all others)\n"
