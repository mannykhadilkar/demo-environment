#!/bin/sh
kubectl apply -f awsLambda.yaml
export LIST_OF_PLUGINS="$LIST_OF_PLUGINS * <$k8s/awsLambda>\n"

