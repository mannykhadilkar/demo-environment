#!/bin/sh
http -f PATCH $ADMIN_HOST:$ADMIN_PORT/default/workspaces/default config.portal=true
http -f PATCH $ADMIN_HOST:$ADMIN_PORT/default/workspaces/default config.portal_auto_approve=true
if [ -z "$INTERACTIVE_SETUP" ]; then
  export INTERACTIVE_SETUP=false
fi

if "$INTERACTIVE_SETUP" eq "true"; then
  echo "Enter dev portal user's email: "
  read DEV_EMAIL
  echo "Set dev's password: "
  stty -echo
  read DEV_PASSWORD
  stty echo
  http $ADMIN_HOST:$PORTAL_ADMIN_PORT/register email=$DEV_EMAIL password=$DEV_PASSWORD
fi

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"sven@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Sven Walther\"}"}'

DEV_CONSUMER_ID=$(curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"developer@apim.eu","password":"KongRul3z!","meta":"{\"full_name\":\"Contract Developer\"}"}' \
  | jq -r '.developer.consumer.id' )

http $ADMIN_HOST:$ADMIN_PORT/consumers/$DEV_CONSUMER_ID/key-auth key=developer

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"aaron@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Aaron Miller\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"melissa.van.der.hecht@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Melissa van der Hecht\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"anantha@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Anantha Kasetty\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"claudio.acquaviva@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Claudio Acquaviva\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"damon.sorrentino@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Damon Sorrentino\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"fel@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Felderi Santiago\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"manny@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Manny Khadilkar\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"mansimran.singh@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Mansimran Singh\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"mmarquez@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Marco Marquez\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"mos.amokhtari@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Mos Amokhtari\"}"}'

curl -X POST \
  "http://$ADMIN_HOST:$PORTAL_ADMIN_PORT/register?=" \
  -H 'Content-Type: application/json' \
  -H "Origin: http://$ADMIN_HOST:$PORTAL_PORT" \
  -H "Referer: http://$ADMIN_HOST:$PORTAL_PORT/default/register" \
  -H 'cache-control: no-cache' \
  -d '{"email":"nick@konghq.com","password":"KongRul3z!","meta":"{\"full_name\":\"Nick Rago\"}"}'
