#!/bin/sh

if [ -z "${ADMIN_PORT}" ]; then
  echo "ADMIN_PORT is not set - sourcing default config for local docker-compose based configuration"
  . ../1-environment/docker-compose.sh
fi

export INTERACTIVE_SETUP=false 
if [ -z "$1" ]; then
  export INTERACTIVE_SETUP=false 
else
  if [ "$1" = "interactive" ]; then
    echo "Enabling interactive setup mode"
    export INTERACTIVE_SETUP=true
  fi
fi

if [ -z "$DEMO_WORKSPACES" ]; then
  export DEMO_WORKSPACES="germanCarBrands" 
fi

echo "Checking if Kong has started..."
while true
do
    STATUS_CODE=$(curl -s -o /dev/null -w "%{http_code}" $ADMIN_HOST:$ADMIN_PORT/status)
    if [ $STATUS_CODE -eq 200 ]; then
	echo "OK"
	break
    else
	echo "Not yet. Got status: $STATUS_CODE"
        sleep 5s
    fi
done

# this creates the folder for possible extra pages to be uploaded to the dev portal
export PAGES_FOLDER=~/.demo-env/portalPages
echo "Creating root CA"
if [ ! -d "$PAGES_FOLDER" ]
then
  mkdir -p $PAGES_FOLDER
fi

export LIST_OF_PLUGINS=""

if [ "$ENABLE_THEME_ONLY_MODE" != "true" ]; then
  . ./executeSubscripts.sh
  . ./addDefaultsToAllWorkspaces.sh
fi

./enableDefaultPortal.sh
./publishToDevPortal.sh

if [ -d "$PAGES_FOLDER" ]
then
  rm $PAGES_FOLDER/*
  rmdir $PAGES_FOLDER
fi

echo "The following routes have been created:\n"
echo "$LIST_OF_PLUGINS"
