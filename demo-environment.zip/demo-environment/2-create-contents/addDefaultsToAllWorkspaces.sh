#!/bin/sh
# Adding default service / route / consumer and Prometheus to all workspaces
shared_user=$(http -f $ADMIN_HOST:$ADMIN_PORT/consumers username=sharedUser | jq -r '.id' )
shared_key=$(http -f $ADMIN_HOST:$ADMIN_PORT/consumers/$shared_user/key-auth key=sharedKey | jq -r '.id' )
workspaces=$(http $ADMIN_HOST:$ADMIN_PORT/workspaces | jq -r '.data[].name')
for workspace in $workspaces; do
  if [ ! "$workspace" = "default" ]; then
    http -f $ADMIN_HOST:$ADMIN_PORT/$workspace/services name=$workspace url=http://httpbin/anything
    http -f $ADMIN_HOST:$ADMIN_PORT/$workspace/services/$workspace/routes name=$workspace paths="/$workspace/httpbin"
    KEY_AUTH_ROUTE=$(http -f $ADMIN_HOST:$ADMIN_PORT/$workspace/services/$workspace/routes name=$workspace-keyAuth paths="/$workspace/keyAuth" | jq -r '.id' )
    http -f $ADMIN_HOST:$ADMIN_PORT/$workspace/routes/$KEY_AUTH_ROUTE/plugins name=key-auth
    http $ADMIN_HOST:$ADMIN_PORT/workspaces/$workspace/entities entities=$shared_user
    http $ADMIN_HOST:$ADMIN_PORT/workspaces/$workspace/entities entities=$shared_key

   # Create Admin Role for workspace
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/rbac/roles name=$workspace-admin comment="Full access to all endpoints in workspace"
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/rbac/roles/$workspace-admin/endpoints endpoint=* actions="delete,create,update,read"
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/admins username=$workspace-admin email=$workspace-admin@example.com 
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/admins/$workspace-admin/roles roles=$workspace-admin -f

   # Create Read-Only Role for workspace
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/rbac/roles name=$workspace-read-only comment="Read access to all endpoints in workspace"
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/rbac/roles/$workspace-read-only/endpoints endpoint=* actions="read"
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/admins username=$workspace-read-user email=$workspace-read-user@example.com 
   http POST $ADMIN_HOST:$ADMIN_PORT/$workspace/admins/$workspace-read-user/roles roles=$workspace-read-only -f

    if [ "$ENABLE_PROMETHEUS_GRAFANA" = true ] ; 
    then
      http -f $ADMIN_HOST:$ADMIN_PORT/$workspace/plugins name=prometheus
    fi
  fi
done
  # Re-applying the shared key as otherwise caching might take place
http $ADMIN_HOST:$ADMIN_PORT/consumers/$shared_user/key-auth/$shared_key key=sharedKey
