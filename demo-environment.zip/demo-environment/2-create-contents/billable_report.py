import argparse
import json
import urllib.request
import numpy as np
import pandas as pd
from datetime import datetime

import pytz

parser = argparse.ArgumentParser(description="Fetch billable metrics and create pivot table")
parser.add_argument('--url', dest='url', type=str, required=True,
                    help="Kong Admin API URL to billable metrics, e.g. " \
                         "http://localhost:8001/billable?workspace_id=80c5f919-035a-4796-bee3-f1899f44b85a")
parser.add_argument("--outfile", dest='outfile', type=str, required=True, help="File name must have .xlsx extension")
args = parser.parse_args()

BRONZE = .05
SILVER = .03
GOLD = .01

SHEET_NAME = 'BillingData'

PERIOD_MAP = {
    'month': 'Monthly',
    'day': 'Daily'
}


def determine_price_level(request_count):
    if request_count < 100:
        return BRONZE
    elif 100 < request_count < 250:
        return SILVER
    else:
        return GOLD


response = urllib.request.urlopen(args.url)
data = response.read()
d = json.loads(data)
# print(d)
rows = d.get("data")
if rows:
    customers = set([row.get('username') for row in rows])
    period = set([row.get('period') for row in rows])
    end_row = 3 + len(customers)
    period_date = rows[0]['period_date'] / 1000
    report_date = datetime.fromtimestamp(period_date, pytz.utc)
    df = pd.DataFrame.from_dict(rows, orient='columns')
    df['charge'] = df['value'].apply(lambda x: x * determine_price_level(x))
    table = pd.pivot_table(df, values=['charge', 'value'], columns=['service_name'], index=['username'], aggfunc=np.sum,
                           margins=True, fill_value=0, margins_name='Total')
    writer = pd.ExcelWriter(args.outfile, engine='xlsxwriter')

    table.to_excel(writer, sheet_name=SHEET_NAME)
    workbook = writer.book
    worksheet = writer.sheets[SHEET_NAME]
    chart_sheet = workbook.add_chartsheet(name='CustomerChart')
    chart = workbook.add_chart({'type': 'column'})
    chart_sheet.set_chart(chart)

    chart.set_title({
        'name': '{} Billing by Customer for {}'.format(PERIOD_MAP.get(period.pop()), report_date.strftime('%B %Y'))
    })
    config = {
        'values': '={}!$D$4:$D${}'.format(SHEET_NAME, end_row),
        'name': 'charge',
        'categories': '={}!$A$4:$A${}'.format(SHEET_NAME, end_row),
        'data_labels': {'value': True}
    }
    chart.add_series(config)
    chart.set_x_axis({
        'name': 'Customer Name',
        'name_font': {'size': 14, 'bold': True},
    })
    chart.set_y_axis({
        'name': 'Amount ($)',
        'name_font': {'size': 14, 'bold': True},
    })
    chart.set_size({'x_scale': 1.5, 'y_scale': 2})
    writer.save()
    print("Excel spreadsheet successfully created: {}".format(args.outfile))
