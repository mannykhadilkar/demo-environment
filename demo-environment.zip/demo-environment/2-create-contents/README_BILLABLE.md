In order to use the King billable plugin perform the following steps:

1. Install the billable plugin by running the 
   `0-setup/shared/custom-plugins/addBillable.sh` script.
2. Enable the plugin on a service that has some sort of 
   authentication enabled.
3. Send some requests. Ideally, you should run requests using a few 
   different consumers, so the report shows useful data.
4. Call the billable endpoint to see some data, 
   `http :8001/billable?service_id=xyz&period=hour`
5. Generate a report using the `billable_report.py` program.
   See below for example.

Example:

```
python billable_report.py \
--url "http://localhost:8001/billable?service_id=3279dbb1-e468-4168-a530-9256c1796a1d&period=hour" \
--outfile ~/Desktop/report.xlsx
```

Note: In order to run report, you must have the pandas framework installed
as well as pytz.

`pip install pandas`
`pip install pytz`