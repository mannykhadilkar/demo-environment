#!/bin/sh
export DEMO_ENV=minikube-k4k8s
export ADMIN_HOST=$(minikube -p k4k8s ip)
export PROXY_HOST=$ADMIN_HOST
echo "IP of Kubernetes: $ADMIN_HOST"
echo "If you want to see the Kubernetes dashboard execute \"minikube --profile k4k8s dashboard &\""
export k8s=$(minikube --profile k4k8s service -n kong kong-proxy --url | head -1)
echo "To access the Kong Ingress proxy use \$k8s as hostname, for example \"http \$k8s/anything\""

