#!/bin/sh
export DEMO_ENV=kubernetes
export ADMIN_HOST=$(kubectl config view -o jsonpath='{.clusters[0].cluster.server}' | awk -F: '{print $2}' | sed 's:^/*::')
export PROXY_HOST=$ADMIN_HOST
export MANAGER_HOST=$ADMIN_HOST
export PORTAL_HOST=$ADMIN_HOST
export PORTAL_ADMIN_HOST=$ADMIN_HOST
export ADMIN_PORT=$(oc get services kong-admin -o json | jq '.spec.ports[0].nodePort')
export PROXY_PORT=$(oc get services kong-proxy -o json | jq '.spec.ports[0].nodePort')
export MANAGER_PORT=$(oc get services kong-manager -o json | jq '.spec.ports[0].nodePort')
export PORTAL_PORT=$(oc get services kong-portal -o json | jq '.spec.ports[0].nodePort')
export PORTAL_ADMIN_PORT=$(oc get services kong-portal-admin -o json | jq '.spec.ports[0].nodePort')

echo "**** Environment"
echo "Admin-Host: $ADMIN_HOST"
echo "Admin-Port: $ADMIN_PORT"
echo "Proxy-Host: $PROXY_HOST"
echo "Proxy-Port: $PROXY_PORT"
echo "Manager-Host: $MANAGER_HOST"
echo "Manager-Port: $MANAGER_PORT"
echo "Portal-Host: $PORTAL_HOST"
echo "Portal-Port: $PORTAL_PORT"
echo "Portal-Admin-Host: $PORTAL_ADMIN_HOST"
echo "Portal-Admin-Port: $PORTAL_ADMIN_PORT"
echo ""
echo "URLs"
echo "Manager: http://$MANAGER_HOST:$MANAGER_PORT (setting KONG_ADMIN_GUI_URL)"
echo "Portal: http://$PORTAL_HOST:$PORTAL_PORT"
echo ""
echo "Portal-Admin-API: http://$PORTAL_ADMIN_HOST:$PORTAL_ADMIN_PORT (setting KONG_PORTAL_API_URL)"
echo "Kong-Admin-API: http://$ADMIN_HOST:$ADMIN_PORT (setting KONG_ADMIN_API_URI)"
echo "Portal-Host: $ADMIN_HOST:$ADMIN_PORT (setting KONG_PORTAL_GUI_HOST)"

