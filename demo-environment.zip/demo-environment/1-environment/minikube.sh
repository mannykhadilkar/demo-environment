#!/bin/sh
export DEMO_ENV=minikube
export ADMIN_HOST=$(minikube ip)
export INGRESS_ADMIN_HOST=$ADMIN_HOST
export BRAIN_HOST=$ADMIN_HOST
export PROXY_HOST=$ADMIN_HOST
export PROXY_SSL_HOST=$ADMIN_HOST
export MANAGER_HOST=$ADMIN_HOST
export PORTAL_HOST=$ADMIN_HOST
export PORTAL_ADMIN_HOST=$ADMIN_HOST
export WEBSERVER_HOST=$ADMIN_HOST

export ADMIN_PORT=$(kubectl get services kong-admin -o json -n kong-enterprise | jq '.spec.ports[0].nodePort')
export PROXY_PORT=$(kubectl get services kong-proxy -o json -n kong-enterprise | jq '.spec.ports[0].nodePort')
export PROXY_SSL_PORT=$(kubectl get services kong-proxy-ssl -o json -n kong-enterprise | jq '.spec.ports[0].nodePort')
export MANAGER_PORT=$(kubectl get services kong-manager -n kong-enterprise -o json | jq '.spec.ports[0].nodePort')
export PORTAL_PORT=$(kubectl get services kong-portal -n kong-enterprise -o json | jq '.spec.ports[0].nodePort')
export PORTAL_ADMIN_PORT=$(kubectl get services kong-portal-admin -n kong-enterprise -o json | jq '.spec.ports[0].nodePort')
export INGRESS_ADMIN_PORT=$(kubectl get services kong-ingress-controller -n kong-ingress -o json | jq '.spec.ports[0].nodePort')
export BRAIN_PORT=$(kubectl get services brain-admin -n kong-brain-immunity -o json | jq '.spec.ports[0].nodePort')
export COLLECTOR_HOST=brain-admin.kong-brain-immunity
export COLLECTOR_PORT=5000
export WEBSERVER_PORT=$(kubectl get services webserver -n kong-enterprise -o json | jq '.spec.ports[0].nodePort')

echo "**** Environment"
echo "Admin: $ADMIN_HOST:$ADMIN_PORT"
echo "Proxy: $PROXY_HOST:$PROXY_PORT"
echo "Proxy-SSL: $PROXY_HOST:$PROXY_SSL_PORT"
echo "Manager-Host: $MANAGER_HOST:$MANAGER_PORT"
echo "Portal: $PORTAL_HOST:$PORTAL_PORT"
echo "Portal-Admin: $PORTAL_ADMIN_HOST:$PORTAL_ADMIN_PORT"
echo "Ingress-Admin: $INGRESS_ADMIN_HOST:$INGRESS_ADMIN_PORT"
echo "Brain-Admin: $BRAIN_HOST:$BRAIN_PORT"
echo ""
echo "URLs"
if [ "$USE_INGRESS_CONTROLLER" = true ]; then
  echo "\n*** Ingress Controller based access\n"
  echo " Proxy: https://local-proxy.apim.eu/"
  echo " Admin: https://local-admin.apim.eu/"
  echo " Manager: https://local-manager.apim.eu"
  echo " Portal: https://local-portal.apim.eu"
  echo " Portal-API: https://local-portal-admin.apim.eu\n"
  echo "!!! You must have the following entry in your /etc/hosts to demo the ingress controller:"
  echo  " $(minikube ip) local-proxy.apim.eu local-admin.apim.eu local-manager.apim.eu local-portal.apim.eu local-portal-admin.apim.eu"
else
  echo "Manager: http://$MANAGER_HOST:$MANAGER_PORT (setting KONG_ADMIN_GUI_URL)"
  echo "Portal: http://$PORTAL_HOST:$PORTAL_PORT"
  echo ""
  echo "Portal-Admin-API: http://$PORTAL_ADMIN_HOST:$PORTAL_ADMIN_PORT (setting KONG_PORTAL_API_URL)"
  echo "Kong-Admin-API: http://$ADMIN_HOST:$ADMIN_PORT (setting KONG_ADMIN_API_URI)"
  echo "Portal-Host: $ADMIN_HOST:$PORTAL_PORT (setting KONG_PORTAL_GUI_HOST)"
fi


