#!/bin/sh
export DEMO_ENV=docker-compose
export ADMIN_HOST=localhost
export PROXY_HOST=$ADMIN_HOST
export MANAGER_HOST=$ADMIN_HOST
export BRAIN_HOST=$ADMIN_HOST
export PORTAL_HOST=$ADMIN_HOST
export PORTAL_ADMIN_HOST=$ADMIN_HOST
export ADMIN_PORT=8001
export PROXY_PORT=8000
export PROXY_SSL_PORT=8443
export HTTP2_PROXY_PORT=9080
export HTTP2_PROXY_SSL_PORT=9081
export MANAGER_PORT=8002
export PORTAL_PORT=8003
export PORTAL_ADMIN_PORT=8004
export BRAIN_PORT=5000
export COLLECTOR_HOST=collector
export COLLECTOR_PORT=5000
export WEBSERVER_HOST=$ADMIN_HOST
export WEBSERVER_PORT=10800

echo "\n**** Kong configuration settings"
echo "Portal-Admin-API: http://$PORTAL_ADMIN_HOST:$PORTAL_ADMIN_PORT (setting KONG_PORTAL_API_URL)"
echo "Kong-Admin-API: http://$ADMIN_HOST:$ADMIN_PORT (setting KONG_ADMIN_API_URI)"
echo "Portal-Host: $ADMIN_HOST:$ADMIN_PORT (setting KONG_PORTAL_GUI_HOST)"

echo "**** Kong-Environment"
echo "Admin: $ADMIN_HOST:$ADMIN_PORT"
echo "Proxy: $PROXY_HOST:$PROXY_PORT"
echo "Proxy-SSL: $PROXY_HOST:$PROXY_SSL_PORT"
echo "gRPC Proxy: $PROXY_HOST:$HTTP2_PROXY_PORT"
echo "gRPC Proxy-SSL: $PROXY_HOST:$HTTP2_PROXY_SSL_PORT"
echo "Manager: $MANAGER_HOST:$MANAGER_PORT"
echo "Portal: $PORTAL_HOST:$PORTAL_PORT"
echo "Portal-Admin: $PORTAL_ADMIN_HOST:$PORTAL_ADMIN_PORT"
echo "Brain: $BRAIN_HOST:$BRAIN_PORT"
echo ""
echo "**** User interfaces URLs"
echo "Manager: http://$MANAGER_HOST:$MANAGER_PORT"
echo "Portal:  http://$PORTAL_HOST:$PORTAL_PORT"
echo "Grafana: http://$ADMIN_HOST:10100 (admin/admin)"
echo "Syslog:  http://$ADMIN_HOST:10200 (kong/kong)"

if [ "$ENABLE_ELK" = true ]
then
  export KIBANA_HOST=$ADMIN_HOST
  export KIBANA_PORT=5601
  echo "Kibana:  http://$KIBANA_HOST:$KIBANA_PORT" 
fi

echo ""
