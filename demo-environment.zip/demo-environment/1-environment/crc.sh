#!/bin/sh
export DEMO_ENV=crc
export ADMIN_HOST=api.crc.testing
export PROXY_HOST=$ADMIN_HOST
export MANAGER_HOST=$ADMIN_HOST
export PORTAL_HOST=$ADMIN_HOST
export PORTAL_ADMIN_HOST=$ADMIN_HOST
export WEBSERVER_HOST=$ADMIN_HOST
export ADMIN_PORT=$(oc get services kong-admin -o json | jq '.spec.ports[0].nodePort')
export PROXY_PORT=$(oc get services kong-proxy -o json | jq '.spec.ports[0].nodePort')
export PROXY_SSL_PORT=$(oc get services kong-proxy-ssl -o json | jq '.spec.ports[0].nodePort')
export MANAGER_PORT=$(oc get services kong-manager -o json | jq '.spec.ports[0].nodePort')
export PORTAL_PORT=$(oc get services kong-portal -o json | jq '.spec.ports[0].nodePort')
export PORTAL_ADMIN_PORT=$(oc get services kong-portal-admin -o json | jq '.spec.ports[0].nodePort')
export WEBSERVERL_PORT=$(oc get services webserver -o json | jq '.spec.ports[0].nodePort')
export COLLECTOR_HOST=brain-admin.kong-brain-immunity

echo "**** Environment"
echo "Admin: $ADMIN_HOST:$ADMIN_PORT"
echo "Proxy: $PROXY_HOST:$PROXY_PORT"
echo "Proxy-SSL: $PROXY_HOST:$PROXY_SSL_PORT"
echo "Manager: $MANAGER_HOST:$MANAGER_PORT"
echo "Portal: $PORTAL_HOST:$PORTAL_PORT"
echo "Portal-Admin: $PORTAL_ADMIN_HOST:$PORTAL_ADMIN_PORT"
echo ""
echo "URLs"
echo "Manager: http://$MANAGER_HOST:$MANAGER_PORT (setting KONG_ADMIN_GUI_URL)"
echo "Portal: http://$PORTAL_HOST:$PORTAL_PORT"
echo ""
echo "Portal-Admin-API: http://$PORTAL_ADMIN_HOST:$PORTAL_ADMIN_PORT (setting KONG_PORTAL_API_URL)"
echo "Kong-Admin-API: http://$ADMIN_HOST:$ADMIN_PORT (setting KONG_ADMIN_API_URI)"
echo "Portal-Host: $ADMIN_HOST:$PORTAL_PORT (setting KONG_PORTAL_GUI_HOST)"
echo "To see the web user interface open https://console-openshift-console.apps-crc.testing/ with username and password developer"

