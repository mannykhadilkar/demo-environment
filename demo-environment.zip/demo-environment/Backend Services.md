# Example backend services

The demo environment includes some example backend systems to be used for services and upstreams even when being offline:

- httpbin at http://httpbin (see <http://httpbin.org>)
- JSONPlaceholder at http://placeholder (see <https://jsonplaceholder.typicode.com>)
- Star Wars API ("Swapi") at http://swapi (see <https://swapi.co>)