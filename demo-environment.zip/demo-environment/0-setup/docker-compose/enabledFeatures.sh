#!/bin/sh
ADDITIONAL_COMPONENTS=""

if [ "$ENABLE_OPENLDAP" = true ] ; 
then
  echo "[FEATURE] OpenLDAP enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f openldap.yaml"
fi

if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ; 
then
  echo "[FEATURE] Brain and Immunity enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f brain-immunity.yaml"
fi

if [ "$ENABLE_REDIS" = true ] ; 
then
  echo "[FEATURE] Redis enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f redis.yaml"
fi

if [ "$ENABLE_DATADOG" = true ] ; 
then
  echo "[FEATURE] DataDog enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f datadog.yaml"

  if [ -f ~/.demo-env/vars ]; 
  then
    echo "Found ~/.demo-env/vars - sourcing it\n"
    . ~/.demo-env/vars 
  fi

  if [ -z "$DD_API_KEY" ]
  then
    echo "Datadog API Key: "
    read DD_API_KEY
    export DD_API_KEY
  fi
fi

if [ "$ENABLE_ELK" = true ]
then
  echo "[FEATURE] ELK enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f elk_stack.yaml"
fi

if [ "$ENABLE_PROMETHEUS_GRAFANA" = true ] ; 
then
  echo "[FEATURE] Prometheus and Grafana enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f prometheus_grafana.yaml"
fi

if [ "$ENABLE_SYSLOG" = true ] ; 
then
  echo "[FEATURE] Syslog enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f syslog.yaml"
fi

if [ "$ENABLE_KAFKA" = true ] ;
then
  echo "[FEATURE] Kafka enabled"
  ADDITIONAL_COMPONENTS="$ADDITIONAL_COMPONENTS -f kafka_zookeeper.yaml"
fi

export ADDITIONAL_COMPONENTS
