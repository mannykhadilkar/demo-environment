#!/bin/sh
export ADDITIONAL_COMPONENTS=""

. ./enabledFeatures.sh

docker-compose -f kong.yaml $ADDITIONAL_COMPONENTS down --remove-orphans
