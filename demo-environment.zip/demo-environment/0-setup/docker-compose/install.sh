#!/bin/sh
LOGGED_IN=true
bintrays[0]="kong-docker-kong-enterprise-edition-docker.bintray.io"
bintrays[1]="kong-docker-kong-brain-immunity-base.bintray.io"

for bintray in ${bintrays[@]}; do 
  echo "Checking if logged in to $bintray already"
  if ! grep -q "$bintray" ~/.docker/config.json ; then
    echo " -> Not logged in"
    LOGGED_IN=false
  else 
    echo " -> Already logged in"
  fi
done

if [ $LOGGED_IN = false ] ; then
  echo "Trying to find bintray credentials in ~/.bintray_docker or in env variables BINTRAY_USER and BINTRAY_PASSWORD\n"

  if [ -f ~/.bintray_docker ]; then
    echo "Found ~/.bintray_docker - sourcing it\n"
    . ~/.bintray_docker 
  fi

  if [ -z "$BINTRAY_USER" ]
  then
    echo "Bintray username: "
    read BINTRAY_USER
  fi

  if [ -z "$BINTRAY_PASSWORD" ]
  then
    echo "Bintray password/token: "
    stty -echo
    read BINTRAY_PASSWORD
    stty echo
  fi

  for bintray in ${bintrays[@]}; do
    if ! grep -q "$bintray" ~/.docker/config.json ; then
      echo "Logging in to $bintray"
      docker login -u $BINTRAY_USER -p $BINTRAY_PASSWORD $bintray
    fi
  done
fi

# ***** Optional features section ******

export ADDITIONAL_COMPONENTS=""

. ./enabledFeatures.sh


docker-compose -f kong.yaml $ADDITIONAL_COMPONENTS up -d

echo "\n"
. ../../1-environment/docker-compose.sh

if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ; 
then  
  ../shared/Brain/addSlackNotificationWebhook.sh
fi

if [ "$ENABLE_CUSTOM_PLUGINS" = true ] ; 
then
  echo "\n [FEATURE] custom plugin enabled"
  . ../shared/custom-plugins/addCustomPlugin.sh
fi
