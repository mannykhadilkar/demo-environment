#!/bin/sh
echo "(Re)starting Minikube"
minikube -p k4k8s --cpus 2 --memory 3300 start

echo "Trying to find bintray credentials in ~/.bintray_docker or in env variables BINTRAY_USER, BINTRAY_PASSWORD and BINTRAY_EMAIL\n"

if [ -f ~/.bintray_docker ]; then
  echo "Found ~/.bintray_docker - sourcing it\n"
  . ~/.bintray_docker 
fi

if [ -z "$BINTRAY_USER" ]
then
  echo "Bintray username: "
  read BINTRAY_USER
fi

if [ -z "$BINTRAY_PASSWORD" ]
then
  echo "Bintray password/token: "
  stty -echo
  read BINTRAY_PASSWORD
  stty echo
fi

if [ -z "$BINTRAY_EMAIL" ]
then
  echo "Bintray email: "
  read BINTRAY_EMAIL
fi

kubectl apply -f namespace_kong.yaml 

echo "\n*** Creating bintray secrets for user $BINTRAY_USER"
kubectl create secret -n kong docker-registry kong-enterprise-docker --docker-server=kong-docker-kong-enterprise-k8s.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL -n kong

echo "\n*** Storing license as a secret"
kubectl apply -f ../shared/kong_license.yaml -n kong

kubectl apply -f namespace_backends.yaml
kubectl create -f ../shared/Backends/httpbin.yaml -n backends
kubectl create -f ../shared/Backends/anotherHttpbin.yaml -n backends
kubectl create -f ../shared/Backends/jsonplaceholder.yaml -n backends
kubectl create -f ../shared/redis.yaml -n kong
kubectl apply -f k4k8s-enterprise.yaml
kubectl apply -f httpbin_anything_path.yaml -n backends
export k8s=$(minikube --profile k4k8s service -n kong kong-proxy --url | head -1)
