#!/bin/sh
kubectl delete -f namespace_backends.yaml
kubectl delete -f k4k8s-enterprise.yaml
if [ "$ENV_IN_RESTART" = true ] ; 
then
  echo "We are restarting, no need to shut down Minikube"
else
  minikube -p k4k8s stop
fi
