# Setup
This scripts automatically installs:

- Postgres database
- a Kong gateway deployment (three nodes by default)
- Ingress controller
- httpbin
- JSONPlaceholder

- Make sure you have the latest version of Docker Desktop installed.
- Open the Preferences panel and click on the Kubernetes icon
- Check the "Enable Kubernetes" option and hit apply

Once k8s is enabled in Docker, it installs a different version of `kubectl`. The path is `/usr/local/bin/kubectl.docker`. If you have another version in there, rename it to `/usr/local/bin/kubectl.old` or something. Then, create a symbolic link like so:

`sudo ln -s /usr/local/bin/kubectl.docker /usr/local/bin/kubectl`

Note: Docker will probably download some requirements initially. After Kubernetes is running, expenad the Docker icon in your menu bar and click on "Kubernetes". You should see `docker-desktop`. If it is not checked, check it.

Run `./kong.sh start docker-k8s` to run demo environment.
