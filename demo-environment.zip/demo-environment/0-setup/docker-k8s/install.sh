#!/bin/sh
echo "Trying to find bintray credentials in ~/.bintray_docker or in env variables BINTRAY_USER, BINTRAY_PASSWORD and BINTRAY_EMAIL\n"

if [ -f ~/.bintray_docker ]; then
  echo "Found ~/.bintray_docker - sourcing it\n"
  . ~/.bintray_docker 
fi

if [ -z "$BINTRAY_USER" ]
then
  echo "Bintray username: "
  read BINTRAY_USER
fi

if [ -z "$BINTRAY_PASSWORD" ]
then
  echo "Bintray password/token: "
  stty -echo
  read BINTRAY_PASSWORD
  stty echo
fi

if [ -z "$BINTRAY_EMAIL" ]
then
  echo "Bintray email: "
  read BINTRAY_EMAIL
fi

echo "\n*** Creating namespaces"
kubectl create -f namespace_kong.yaml
kubectl create -f namespace_database.yaml
kubectl create -f brain-immunity/namespace_brain_immunity.yaml

echo "\n*** Creating bintray secrets for user $BINTRAY_USER"
kubectl create secret docker-registry bintray-kong --docker-server=kong-docker-kong-enterprise-edition-docker.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL -n kong-enterprise
kubectl create secret docker-registry bintray-kong-rc --docker-server=kong-docker-kong-enterprise-rc-docker.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL -n kong-enterprise
kubectl create secret docker-registry bintray-kong-brain --docker-server=kong-docker-kong-brain-immunity-base.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL -n kong-brain-immunity

echo "\n*** Creating Postgres"
kubectl create -f postgres.yaml -n database
echo "\n... waiting a few seconds for Postgres to start\n"
sleep 5s

echo "\n*** Storing license as a secret"
kubectl create -f ../shared/kong_license.yaml -n kong-enterprise

echo "\n*** Initiating Kong migration"
kubectl create -f kong_migration_postgres.yaml -n kong-enterprise
echo "\n... waiting a few seconds for Kong to finish migration\n"
sleep 5s

echo "\n*** Deploying Kong"
kubectl apply -f kong_postgres.yaml -n kong-enterprise

echo "\n*** Creating example backend services"
kubectl create -f httpbin.yaml -n kong-enterprise
kubectl create -f jsonplaceholder.yaml -n kong-enterprise
kubectl create -f webserver.yaml -n kong-enterprise

echo "\n*** Adding additional components"
kubectl create -f redis.yaml -n kong-enterprise
kubectl create -f openldap.yaml -n kong-enterprise

./patch_settings.sh

./install_ingress.sh

if [ -z "$DISABLE_BRAIN" ]
then
  ./install_brain_immunity.sh
  echo "\n"
  . ../../1-environment/docker-k8s.sh
  ../shared/Brain/addSlackNotificationWebhook.sh
else
  echo "\n! Brain installation has been disabled by DISABLE_BRAIN being set"
  echo "\n"
  . ../../1-environment/docker-k8s.sh
fi


