# Setup
Setup not added right now but MiniShift setup should work without the automated patching (as "minishift ip" is not available)
