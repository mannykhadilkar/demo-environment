#!/bin/sh
echo "*** Logging in as system with default credentials"
#oc login -u system:admin
oc login -u developer

echo "\n*** Creating project"
oc new-project kong-enterprise

echo "\n*** Lowering security settings (temporary workaround)"
oc login -u system:admin
oc adm policy add-scc-to-user anyuid system:serviceaccount:kong-enterprise:default
oc login -u developer


echo "\nTrying to find bintray credentials in ~/.bintray_docker or in env variables BINTRAY_USER, BINTRAY_PASSWORD and BINTRAY_EMAIL\n"

if [ -f ~/.bintray_docker ]; then
  echo "Found ~/.bintray_docker - sourcing it\n"
  . ~/.bintray_docker 
fi

if [ -z "$BINTRAY_USER" ]
then
  echo "Bintray username: "
  read BINTRAY_USER
fi

if [ -z "$BINTRAY_PASSWORD" ]
then
  echo "Bintray password/token: "
  stty -echo
  read BINTRAY_PASSWORD
  stty echo
fi

if [ -z "$BINTRAY_EMAIL" ]
then
  echo "Bintray email: "
  read BINTRAY_EMAIL
fi

echo "\n*** Creating bintray secret for user $BINTRAY_USER"
oc create secret docker-registry bintray-kong --docker-server=kong-docker-kong-enterprise-edition-docker.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL 
oc create secret docker-registry bintray-kong-brain --docker-server=kong-docker-kong-brain-immunity-base.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL -n kong-enterprise

echo "\n*** Creating Postgres"
oc create -f postgres.yaml
echo "\n... waiting a few seconds for Postgres to start\n"
sleep 5s

echo "\n*** Storing license as a secret"
oc create -f ../shared/kong_license.yaml

echo "\n*** Initiating Kong migration"
oc create -f kong_migration_postgres.yaml
echo "\n... waiting a few seconds for Kong to finish migration\n"
sleep 5s

echo "\n*** Deploying Kong"
oc create -f kong_postgres.yaml 

echo "\n*** Creating example backend services"
oc create -f ../shared/Backends/httpbin.yaml 
oc create -f ../shared/Backends/jsonplaceholder.yaml

echo "\n*** Adding additional components"
if [ "$ENABLE_REDIS" = true ] ; 
then
  oc create -f redis.yaml
fi

if [ "$ENABLE_OPENLDAP" = true ] ; 
then
  oc create -f openldap.yaml
fi



./patch_settings.sh

if [ "$ENABLE_INGRESS_CONTROLLER" = true ]; 
then
  ./install_ingress.sh
fi

echo "\n"
. ../../1-environment/minishift.sh
