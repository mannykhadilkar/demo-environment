# Setup
The scripts and/or YAML-files in the subfolders can be used to create the demo environment including Postgres, Kong and some more services (e.g. syslog or httpbin). As of now only docker-compose, minikube and minishift are complete.

TODO: Add Cassandra option