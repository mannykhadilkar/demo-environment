#!/bin/sh
kubectl create namespace kong-sidecar
kubectl label namespace kong-sidecar kong-sidecar-injection=disabled

### Create a key+certificate for the control plane
openssl req -new -nodes -batch -keyout privkey.pem -out csr.pem -subj /CN=kong-control-plane.kong-sidecar.svc
cat <<EOF | kubectl -n kong-sidecar create -f -
apiVersion: certificates.k8s.io/v1beta1
kind: CertificateSigningRequest
metadata:
  name: kong-control-plane.kong-sidecar.svc
spec:
  request: $(cat csr.pem | base64 | tr -d '\n')
  usages:
  - digital signature
  - key encipherment
  - server auth
EOF

kubectl -n kong-sidecar certificate approve kong-control-plane.kong-sidecar.svc
kubectl -n kong-sidecar get csr kong-control-plane.kong-sidecar.svc -o jsonpath='{.status.certificate}' | base64 --decode > cert.pem
kubectl -n kong-sidecar create secret tls kong-control-plane.kong-sidecar.svc --key=privkey.pem --cert=cert.pem
kubectl -n kong-sidecar delete csr kong-control-plane.kong-sidecar.svc
rm privkey.pem
rm csr.pem
rm cert.pem

### Start control plane
kubectl -n kong-sidecar apply -f sidecar-injector/kong-control-plane.yaml

### Wait for startup
echo "Waiting for startup"
sleep 50

### Turn on kong plugins
KONG_ADMIN_URL=$(minikube service -n kong-sidecar kong-control-plane --url | head -n 1)
curl $KONG_ADMIN_URL/plugins -d name=kubernetes-sidecar-injector -d config.image=kong:1.3.0

cat <<EOF | kubectl -n kong-sidecar apply -f -
apiVersion: admissionregistration.k8s.io/v1beta1
kind: MutatingWebhookConfiguration
metadata:
  name: kong-sidecar-injector
webhooks:
- name: kong.sidecar.injector
  rules:
  - apiGroups: [""]
    apiVersions: ["v1"]
    resources: ["pods"]
    operations: [ "CREATE" ]
  failurePolicy: Fail
  namespaceSelector:
    matchExpressions:
    - key: kong-sidecar-injection
      operator: NotIn
      values:
      - disabled
  clientConfig:
    service:
      namespace: kong-sidecar
      name: kong-control-plane
      path: /kubernetes-sidecar-injector
    caBundle: $(kubectl config view --raw --minify --flatten -o jsonpath='{.clusters[].cluster.certificate-authority-data}')
EOF
