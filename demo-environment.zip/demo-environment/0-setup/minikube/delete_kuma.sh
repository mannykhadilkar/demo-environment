#!/bin/sh
kubectl delete -f kuma/namespace_kuma.yaml
kumactl install control-plane | kubectl delete -f -
