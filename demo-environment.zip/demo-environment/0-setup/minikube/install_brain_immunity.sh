#!/bin/sh
echo "\n*** Creating brain namespace"
kubectl create -f brain-immunity/namespace_brain_immunity.yaml

echo "\n*** Deploying Brain and immunity"
kubectl apply -f brain-immunity/brain_immunity.yaml -n kong-brain-immunity
