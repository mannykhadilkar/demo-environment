#!/bin/sh
kumactl install control-plane | kubectl apply -f -
kubectl apply -f kuma/service_kuma_admin.yaml -n kuma-system
echo "Waitung for sidecar injector having been intialized"
kubectl -n kuma-system wait --for=condition=available deployment/kuma-injector
kumactl config control-planes remove --name=Minikube 
export KUMA_ADMIN_PORT=$(kubectl get services kuma-admin -o json -n kuma-system | jq '.spec.ports[0].nodePort')
export KUMA_ADMIN_HOST=$(minikube ip)
kumactl config control-planes add --name=Minikube --address=http://$KUMA_ADMIN_HOST:$KUMA_ADMIN_PORT
kubectl create -f kuma/namespace_kuma.yaml
kubectl create -f ../shared/zipkin.yaml -n kuma-system
kubectl apply -f kuma/kuma_policy_zipkin.yaml
kubectl apply -f kuma/kuma_policy_mtls.yaml
kubectl create -f kuma/echo_service.yaml
kubectl create -f httpbin.yaml -n kuma-mesh



