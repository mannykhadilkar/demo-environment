#!/bin/sh
kubectl delete -f namespace_kong.yaml
kubectl delete -f ingress/kong_ingress_controller.yaml
kubectl delete -f ingress/namespace_kong_ingress.yaml
kubectl delete -f brain-immunity/namespace_brain_immunity.yaml
kubectl delete -f namespace_database.yaml
kubectl delete namespace kong-brain-immunity
kubectl delete namespace kong-sidecar

