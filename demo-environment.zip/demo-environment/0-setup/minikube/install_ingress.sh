#!/bin/sh
mkdir apim.eu
cd apim.eu
curl -o apim.keys.tgz -u kong:KongRul3z!  https://www.apim.eu/download/apim.keys.tgz
tar xzf apim.keys.tgz
kubectl create secret tls apim-secret --key ./privkey.pem --cert ./fullchain.pem -n kong-enterprise
cd ..
rm -R apim.eu

kubectl create -f ingress/namespace_kong_ingress.yaml
kubectl create -f ingress/kong_ingress_controller.yaml
kubectl create -f ingress/kong_ingress_rule.yaml -n kong-enterprise

echo "*** Ingress controller created"
echo " Proxy: https://local-proxy.apim.eu/"
echo " Admin: https://local-admin.apim.eu/\n"
echo " Manager: https://local-manager.apim.eu\n"
echo " Portal: https://local-portal.apim.eu\n"
echo " Portal-API: https://local-portal-admin.apim.eu\n\n"
echo "!!! You must have the following entry in your /etc/hosts to demo the ingress controller:"
echo  " $(minikube ip) local-proxy.apim.eu local-admin.apim.eu local-manager.apim.eu local-portal.apim.eu local-portal-admin.apim.eu"
