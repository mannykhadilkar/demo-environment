#!/bin/sh
echo "\n*** Patching the url settings for Manager and portal"
. ../../1-environment/minikube.sh > /dev/null
cp kong_patch_settings.yaml.template kong_patch_settings.yaml

if [ "$USE_INGRESS_CONTROLLER" = true ]; then
  sed -i -e "s/admin_gui_url/https\:\/\/local-manager.apim.eu/g" kong_patch_settings.yaml
  sed -i -e "s/portal_gui_host/local-portal.apim.eu/g" kong_patch_settings.yaml
  sed -i -e "s/portal_api_url/https\:\/\/local-portal-admin.apim.eu/g" kong_patch_settings.yaml
  sed -i -e "s/admin_api_url/https\:\/\/local-admin.apim.eu/g" kong_patch_settings.yaml
  sed -i -e "s/value\:\ http/value\:\ https/g" kong_patch_settings.yaml
  sed -i -e "s/\"cookie_secure\"\:false/\"cookie_secure\"\:true,\"cookie_samesite\"\:\"off\",\"cookie_domain\"\:\".apim.eu\"/g" kong_patch_settings.yaml
else
  sed -i -e "s/admin_gui_url/http\:\/\/$MANAGER_HOST\:$MANAGER_PORT/g" kong_patch_settings.yaml
  sed -i -e "s/portal_gui_host/$ADMIN_HOST\:$PORTAL_PORT/g" kong_patch_settings.yaml
  sed -i -e "s/portal_api_url/http\:\/\/$PORTAL_ADMIN_HOST\:$PORTAL_ADMIN_PORT/g" kong_patch_settings.yaml
  sed -i -e "s/admin_api_url/http\:\/\/$ADMIN_HOST\:$ADMIN_PORT/g" kong_patch_settings.yaml
fi

kubectl apply -f kong_patch_settings.yaml -n kong-enterprise

rm kong_patch_settings.yaml
rm kong_patch_settings.yaml-e
