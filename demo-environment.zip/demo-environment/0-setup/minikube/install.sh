#!/bin/sh
echo "Trying to find bintray credentials in ~/.bintray_docker or in env variables BINTRAY_USER, BINTRAY_PASSWORD and BINTRAY_EMAIL\n"

if [ -f ~/.bintray_docker ]; then
  echo "Found ~/.bintray_docker - sourcing it\n"
  . ~/.bintray_docker 
fi

if [ -z "$BINTRAY_USER" ]
then
  echo "Bintray username: "
  read BINTRAY_USER
fi

if [ -z "$BINTRAY_PASSWORD" ]
then
  echo "Bintray password/token: "
  stty -echo
  read BINTRAY_PASSWORD
  stty echo
fi

if [ -z "$BINTRAY_EMAIL" ]
then
  echo "Bintray email: "
  read BINTRAY_EMAIL
fi

echo "\n*** Creating namespaces"
kubectl create -f namespace_kong.yaml
kubectl create -f namespace_database.yaml
if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ; 
then
  kubectl create -f brain-immunity/namespace_brain_immunity.yaml
fi

echo "\n*** Creating bintray secrets for user $BINTRAY_USER"
kubectl create secret docker-registry bintray-kong --docker-server=kong-docker-kong-enterprise-edition-docker.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL -n kong-enterprise

if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ; 
then
  kubectl create secret docker-registry bintray-kong-brain --docker-server=kong-docker-kong-brain-immunity-base.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL -n kong-brain-immunity
fi

echo "\n*** Creating Postgres"
kubectl create -f postgres.yaml -n database
echo "\n... waiting a few seconds for Postgres to start\n"
sleep 5s

echo "\n*** Storing license as a secret"
kubectl create -f ../shared/kong_license.yaml -n kong-enterprise

echo "\n*** Initiating Kong migration"
kubectl create -f kong_migration_postgres.yaml -n kong-enterprise
echo "\n... waiting a few seconds for Kong to finish migration\n"
sleep 5s

echo "\n*** Deploying Kong"
kubectl apply -f kong_postgres.yaml -n kong-enterprise

echo "\n*** Creating example backend services"
kubectl create -f ../shared/Backends/httpbin.yaml -n kong-enterprise
kubectl create -f ../shared/Backends/jsonplaceholder.yaml -n kong-enterprise
kubectl create -f webserver.yaml -n kong-enterprise

echo "\n*** Adding additional components"

if [ "$ENABLE_REDIS" = true ] ; 
then
  kubectl create -f redis.yaml -n kong-enterprise
fi

if [ "$ENABLE_OPENLDAP" = true ] ; 
then
  kubectl create -f openldap.yaml -n kong-enterprise
fi

./patch_settings.sh

if [ "$ENABLE_INGRESS_CONTROLLER" = true ]; 
then
  ./install_ingress.sh
fi

if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ; 
then
  ./install_brain_immunity.sh
  echo "\n"
  . ../../1-environment/minikube.sh
  ../shared/Brain/addSlackNotificationWebhook.sh
fi


