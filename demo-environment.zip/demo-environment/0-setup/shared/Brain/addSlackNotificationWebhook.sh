#!/bin/sh
echo "Checking if Brain has started..."
while true
do
    STATUS_CODE=$(curl -s -o /dev/null -w "%{http_code}" $BRAIN_HOST:$BRAIN_PORT/status)
    if [ $STATUS_CODE -eq 200 ]; then
        echo "OK"
        break
    else
        echo "Not yet. Got status: $STATUS_CODE"
        sleep 5s
    fi
done
sleep 5
curl -d '{"endpoint":"https://hooks.slack.com/services/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"}' -H "Content-Type: application/json" -X POST http://$BRAIN_HOST:$BRAIN_PORT/notifications/slack/config
