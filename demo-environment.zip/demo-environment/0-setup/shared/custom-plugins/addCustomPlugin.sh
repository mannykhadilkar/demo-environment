#!/bin/sh
PLUGINS="bundled"
mkdir tmp
cd tmp
#git clone https://github.com/svenwal/kong-plugin-newrelic-insights.git
#docker cp kong-plugin-newrelic-insights/kong/plugins/newrelic-insights/  kong-ent1:/usr/local/share/lua/5.1/kong/plugins
#docker exec -ti kong-ent1 /bin/sh -c "KONG_PLUGINS='bundled,newrelic-insights' kong reload"

git clone https://github.com/svenwal/kong-plugin-inject-errors.git
docker cp kong-plugin-inject-errors/kong/plugins/inject-errors/  kong-ent1:/usr/local/share/lua/5.1/kong/plugins
docker exec -ti kong-ent1 /bin/sh -c "KONG_PLUGINS='bundled,inject-errors' kong reload"
docker cp kong-plugin-inject-errors/kong/plugins/inject-errors/  kong-ent2:/usr/local/share/lua/5.1/kong/plugins
docker exec -ti kong-ent2 /bin/sh -c "KONG_PLUGINS='bundled,inject-errors' kong reload"
docker cp kong-plugin-inject-errors/kong/plugins/inject-errors/  kong-ent3:/usr/local/share/lua/5.1/kong/plugins
docker exec -ti kong-ent3 /bin/sh -c "KONG_PLUGINS='bundled,inject-errors' kong reload"
cd ..
rm -Rf tmp
