#!/bin/sh

git clone git@github.com:Kong/kong-plugin-billable.git
pushd kong-plugin-billable
git fetch origin fixes
git checkout fixes

LOCAL_PLUGIN="kong/plugins/billable"
docker cp  $LOCAL_PLUGIN kong-ent1:/usr/local/share/lua/5.1/kong/plugins
docker exec -ti kong-ent1 /bin/sh -c "KONG_PLUGINS='bundled,billable' kong migrations up --v"
docker exec -ti kong-ent1 /bin/sh -c "KONG_PLUGINS='bundled,billable' kong reload"
docker cp  $LOCAL_PLUGIN kong-ent2:/usr/local/share/lua/5.1/kong/plugins
docker exec -ti kong-ent2 /bin/sh -c "KONG_PLUGINS='bundled,billable' kong reload"
docker cp  $LOCAL_PLUGIN kong-ent3:/usr/local/share/lua/5.1/kong/plugins
docker exec -ti kong-ent3 /bin/sh -c "KONG_PLUGINS='bundled,billable' kong reload"

popd
rm -rf kong-plugin-billable