#!/bin/sh
oc delete project kong-enterprise
