#!/bin/sh
echo "*** Logging in as system with default credentials"
oc login -u developer -p developer https://api.crc.testing:6443

echo "\n*** Creating project"
oc new-project kong-enterprise

echo "\n*** Changing security settings (temporary workaround)"
CRC_ADMIN_PASSWORD=$(crc console --credentials | cut -d"'" -f 4 | tail -1)
oc login -u kubeadmin -p $CRC_ADMIN_PASSWORD https://api.crc.testing:6443
oc adm policy add-scc-to-user anyuid system:serviceaccount:kong-enterprise:default
oc login -u developer -p developer https://api.crc.testing:6443


echo "\nTrying to find bintray credentials in ~/.bintray_docker or in env variables BINTRAY_USER, BINTRAY_PASSWORD and BINTRAY_EMAIL\n"

if [ -f ~/.bintray_docker ]; then
  echo "Found ~/.bintray_docker - sourcing it\n"
  . ~/.bintray_docker 
fi

if [ -z "$BINTRAY_USER" ]
then
  echo "Bintray username: "
  read BINTRAY_USER
fi

if [ -z "$BINTRAY_PASSWORD" ]
then
  echo "Bintray API token: "
  stty -echo
  read BINTRAY_PASSWORD
  stty echo
fi

if [ -z "$BINTRAY_EMAIL" ]
then
  echo "Bintray email: "
  read BINTRAY_EMAIL
fi

echo "\n*** Creating bintray secret for user $BINTRAY_USER"
oc create secret docker-registry bintray-kong --docker-server=kong-docker-kong-enterprise-edition-docker.bintray.io --docker-username=$BINTRAY_USER --docker-password=$BINTRAY_PASSWORD --docker-email=$BINTRAY_EMAIL 

echo "\n*** Creating Postgres"
oc create -f postgres.yaml
echo "\n... waiting a few seconds for Postgres to start\n"
sleep 5s

echo "\n*** Storing license as a secret"
oc create -f ../shared/kong_license.yaml

echo "\n*** Initiating Kong migration"
oc create -f kong_migration_postgres.yaml
echo "\n... waiting a few seconds for Kong to finish migration\n"
sleep 5s

echo "\n*** Deploying Kong"
oc create -f kong_postgres.yaml 

echo "\n*** Creating example backend services"
oc create -f ../shared/Backends/httpbin.yaml 
oc create -f ../shared/Backends/jsonplaceholder.yaml

echo "\n*** Adding additional components"
if [ "$ENABLE_REDIS" = true ] ; 
then
  oc create -f redis.yaml
fi

if [ "$ENABLE_ENABLE_OPENLDAP" = true ] ; 
then
  oc create -f openldap.yaml
fi

./patch_settings.sh

echo "\n"
. ../../1-environment/crc.sh
