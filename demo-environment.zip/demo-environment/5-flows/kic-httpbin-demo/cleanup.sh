#!/bin/bash

# Clean up kubernetes environment and reset the demo

kubectl delete KongPlugin httpbin-auth &&
kubectl delete KongPlugin caching &&
kubectl delete KongConsumer gandalf &&
kubectl delete KongCredential gandalf-apikey &&
kubectl delete Ingress demo
echo "all clean!"


