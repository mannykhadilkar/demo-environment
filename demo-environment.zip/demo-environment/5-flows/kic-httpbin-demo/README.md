# Kong for Kubernetes demo

* Start Minikube with k4k8s-enterprise (./kong start minikube-k4k8s
* execute `. ./1-environment/minikube-k4k8s.sh` in order to have Minikube IP address and port in the env variable k8s
* try `http $k8s/anything` - you should get a "route not defined error" (an empty Kong installation)
* `kubectl apply -f 01-ingress` 
* try again `http $k8s/anything` - you should now get a response from httpbin (a pod in the backends namespace)
* now you do `kubectl apply -f 02-caching` and `kubectl apply -f 03-ingress` (or the 04 and 05 ones)
* if you choose 02 and 03: caching pluging is enabled
* if you choose 04 and 05: key auth is used, apikey is "lotr" (as in lord of the rings)
