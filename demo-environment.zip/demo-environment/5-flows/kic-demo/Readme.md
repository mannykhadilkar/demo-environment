# Kong Ingress Controller Demo Flow

## Assumptions

You have a kubernetes dial tone. In other words you can run kubctl commands against a working k8 cluster.

You have an extenal ingress ip address or hostname.

## Overview
We have a very simple user service that we expect to output a list of users from the 
```/users``` path. You can also display individual users by appending their id such as: ```/users/id```

We will show you how to deploy and harden this service using the Kong Ingress Controller for Kubernetes and some very usful plugins.

## Tell 1A
Let's start by showing how easy it is to deploy the Kong Ingress Controller for Kubernetes. 

You will find it is deployed as a set of manifests that include some custom resource definitions (crds for short) this is not unlike how you might deploy your own resources in kubernetes.

## Show 1

```
curl -sL https://bit.ly/k4k8s | kubectl create -f -
```

This has deployed the Kong Ingress Controller within it's own "kong" namespace. Let's take a look:

```
kubectl get all -n kong
```

```
NAME                                        READY   STATUS      RESTARTS   AGE
pod/my-release-kong-68ccf555b8-wqc7w        2/2     Running     5          31d
pod/my-release-kong-init-migrations-t4xd5   0/1     Completed   0          31d
pod/my-release-postgresql-0                 1/1     Running     1          31d

NAME                                     TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
service/my-release-kong-admin            NodePort    10.102.48.130    <none>        8444:32444/TCP   31d
service/my-release-kong-manager          NodePort    10.103.119.221   <none>        8002:32081/TCP   31d
service/my-release-kong-portal           NodePort    10.101.6.189     <none>        8003:32083/TCP   31d
service/my-release-kong-portalapi        NodePort    10.97.192.160    <none>        8004:32085/TCP   31d
service/my-release-kong-proxy            NodePort    10.108.230.91    <none>        80:32080/TCP     31d
service/my-release-postgresql            ClusterIP   10.103.17.142    <none>        5432/TCP         31d
service/my-release-postgresql-headless   ClusterIP   None             <none>        5432/TCP         31d

NAME                              READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/my-release-kong   1/1     1            1           31d

NAME                                         DESIRED   CURRENT   READY   AGE
replicaset.apps/my-release-kong-68ccf555b8   1         1         1       31d

NAME                                     READY   AGE
statefulset.apps/my-release-postgresql   1/1     31d

NAME                                        COMPLETIONS   DURATION   AGE
job.batch/my-release-kong-init-migrations   1/1           38s        31d
```
## Tell 1B

As you can see the ingress controller is made up of native kubernetes resources and will be scaled and managed in the same fashion that you may already be use to as a kubernetes practitioner.

## Tell 2A

Now let's deploy our user service and demonstrate how the Kong Ingress Controller will handle it!

## Show 2

```
cd k8
```

```
kubectl apply -f 01-kong-demo.yaml
```

Now that our service is deployed we can test that it's working with a port-forward command...

```
kubectl port-forward deployment/users 8080:8080
```

```
curl localhost:8080/users
```

```
[{"id":"1","username":"frodo"},{"id":"2","username":"gandalf"}]
```

Now, it's great that it works, but it doesn't really count unless we can get to it from the outside world (without making our customers do a kubectl command).

In order to get to the outside world in kubernetes we will typically use an ingress. Depending on where your cluster is deployed, your ingress default behavior will vary. This is due to the fact that the different cloud providers and kubernetes solutions have different ingress controllers. This is one of a few barriers to multicloud eutopia.

Wouldn't it be nice if we had a standardized ingress controller that could be deployed accross the board? ... Enter the Kong Ingress Controller!

With the Kong Ingress Controller now installed we have a new default behavior for our ingress manifests. Let's add an ingress now.

```
kubectl apply -f 02-ingress.yaml
```

Now we can connect to our service from the outside world. If we inspect the header we can see it is routing through kong!

_connect via Kong studio or Insomnia:_

```
http://<external ip ingress address>:8080/users
```

```
Content-Type	application/json; charset=utf-8
Content-Length	65
Connection	keep-alive
X-Powered-By	Express
ETag	W/"41-ZdhRSN/pbr3ngD1G1IS+6nAGaxI"
Date	Fri, 22 Nov 2019 03:56:06 GMT
X-Kong-Upstream-Latency	81
X-Kong-Proxy-Latency	4
Via	kong/0.36-2-enterprise-edition
```
## Tell 2B

As you can see you can create ingresses in a business as usual mannor and Kong is now the new default behavior!

## Tell 3A

We can do even more however, let's setup a rate limmiter plugin to help protect our service from ddos attacks.

## Show 3

Plugins can be defined just like all other objects in kubernetes as a yaml file:

```
apiVersion: configuration.konghq.com/v1
kind: KongPlugin
metadata:
  name: rl-by-ip
config:
  minute: 5
  limit_by: ip
plugin: rate-limiting
```

As we can see this is a rate-limiting plugin configured to allow 5 hits per minute. Let's deploy it!

```
kubectl apply -f 03-ratelimit.yaml
```

```
kubectl get KongPlugin
```
```
NAME       PLUGIN-TYPE     AGE
rl-by-ip   rate-limiting   18s
```

Now that we have our rate-limiting plugin deployed we still have one more step. We need to decide where to apply it to?

We can apply it to an ingress, this would create a centralized rate-limiter accross all services associated with the ingress.

We could also apply it to an individual service.

In this case we will apply it to our ingress. We can do this with a simple annotation in the metadata section of the ingress:

```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: demo
  annotations:
    plugins.konghq.com: rl-by-ip
spec:
  rules:
  - http:
      paths:
      - path: /app
        backend:
          serviceName: users
          servicePort: 80
```
Let's deploy the updated ingress!

```
kubectl apply -f 04-ingress.yaml
```

Now that our ingress is updated with our plugin, let's take a look!

```
http://<external ip ingress address>:8080/users
```
```
Content-Type	application/json; charset=utf-8
Content-Length	65
Connection	keep-alive
X-Powered-By	Express
ETag	W/"41-ZdhRSN/pbr3ngD1G1IS+6nAGaxI"
Date	Fri, 22 Nov 2019 05:11:08 GMT
X-RateLimit-Limit-minute	5
X-RateLimit-Remaining-minute	4
X-Kong-Upstream-Latency	8
X-Kong-Proxy-Latency	19
Via	kong/0.36-2-enterprise-edition
```

## Tell 3B

As you can see we have applied a rate-limiting plugin to our ingress. This was done just by annotating the ingresses metadata with the plugin name. Again we can apply these plugins on different layers of abstraction such as services as well!

## Tell 4A

Next we will explore some other objects that work with the Kong Ingress Controller. We will define a key-auth plugin that will secure our service to only allow users with an api key. Of coarse that implies we will need both user and credential objects as well, so I will demonstrate how we can create those as well!

## Show 4

First off let's create a key-auth plugin, this is very similair to how we created the rate-limitter:

```
apiVersion: configuration.konghq.com/v1
kind: KongPlugin
metadata:
  name: httpbin-auth
plugin: key-auth
```

Next we will create a KongConsumer, think of this as a user that consumes the api, again this can be done with a simple yaml definition...

```
apiVersion: configuration.konghq.com/v1
kind: KongConsumer
metadata:
  name: gandalf
username: gandalf
```

Now we will put it all together by defining a KongCredential...

```
apiVersion: configuration.konghq.com/v1
kind: KongCredential
metadata:
  name: nedward-apikey
consumerRef: nedward
type: key-auth
config:
  key: 7ab17a7c-8f42-4bf6-9fdb-ec435f7de58d
```

Now we have hard coded the key in this case, but obviously you woul want to use secrets or other means to protect sensitive data ... it a demo though so ...

we can deploy this with a consolidated file with all three of these resources defined.

```
kubectl apply -f 05-key-auth.yaml
```

We still have one last step which is to apply the new key-auth plugin to our ingress, again just like all plugins we could easily apply this to a single service as well.

```
kubectl apply -f 06-ingress.yaml
```

_demonstrate in Kong Studio or Insomnia_

```
http://<external ip address>:32080/users
```

Of coarse that does not work:

```
{
  "message": "No API key found in request"
}
```
but if we add the key it will now work!

```
http://<external ip address>:32080/users?apikey=7ab17a7c-8f42-4bf6-9fdb-ec435f7de58d
```
## Tell 4B

As you can see we have created a KongConsumer, a Kong Credential and implemented a key-auth plugin to secure our site. Moreover we did it in a declaritive, kubernetes native way!

## Take Aways

If you are already sold on Kubernetes you can see implementing Kong Ingress Controller along with many usuful plugins is as easy as deploying any other kubernetes resource!