#!/bin/bash

# Clean up kubernetes environment and reset the demo

kubectl delete KongPlugin httpbin-auth &&
# kubectl delete KongPlugin users-cache &&
kubectl delete KongPlugin rl-by-ip &&
kubectl delete KongConsumer gandalf &&
kubectl delete KongCredential gandalf-apikey &&
kubectl delete Ingress demo &&
kubectl delete deployment users &&
kubectl delete service users

echo "all clean!"


