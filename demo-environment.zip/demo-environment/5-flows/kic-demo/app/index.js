const dotenv = require("dotenv");
const express = require("express");

dotenv.config();

const app = express();

let users = {
  1: {
    id: "1",
    username: "frodo"
  },
  2: {
    id: "2",
    username: "gandalf"
  },
  3: {
    id: "3",
    username: "gimli"
  },
  4: {
    id: "4",
    username: "aragorn"
  },
  5: {
    id: "5",
    username: "legolas"
  },
  6: {
    id: "6",
    username: "sam"
  },
  7: {
    id: "7",
    username: "Pippin"
  }
};

app.get("/users", (req, res) => {
  return res.send(Object.values(users));
});
app.get("/users/:userId", (req, res) => {
  return res.send(users[req.params.userId]);
});

app.listen(process.env.PORT, () =>
  console.log(`Example app listening on port ${process.env.PORT}!`)
);
