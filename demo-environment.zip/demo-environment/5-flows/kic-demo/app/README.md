# kong-demo-app

This is a simple express.js service used for the kong ingress controller demo.

## Run and test locally

Requires the following:
- [node.js](https://nodejs.org/en/)
- create a ```.env``` file with the following content: ```PORT=8080```


Commands:

```
npm install
```
```
npm start
```
```
curl http://localhost:8080
```
## Build the container

```
docker build -t <user-tag>/<image-name> .
```
_make sure to add the dot at the end_

### Test the container locally

```
docker run -p 8080:8080 -d <user-tag>/<image-name>
```
```
curl http://localhost:8080
```
### Stop the container

```
docker ps
```
_copy the container id_

```
docker stop <container id>
```

