#!/bin/sh
if [ -z "${ADMIN_PORT}" ]; then
  echo "ADMIN_PORT is not set - sourcing default config for local docker-compose based configuration"
  . ../1-environment/docker-compose.sh
fi

if [ "$DEMO_ENV" = "docker-compose" ]; 
then
  ports[0]="8000"
  ports[1]="8010"
  ports[2]="8020"
else
  ports[0]=$PROXY_PORT
fi

immunityRequests[0]="/brain/albums?evilCode=DROP"
immunityRequests[1]="/brain/posts/100"
immunityRequests[2]="/brain/albums"
immunityRequests[3]="/brain/posts"
immunityRequests[4]="/brain/posts/1"
immunityRequests[5]="/brain/posts/12 silly=parameter"
immunityRequests[6]="/brain/nonExistent"
immunityRequests[7]="/brain/posts?iDidSomethingWrong=true"
immunityRequests[8]="/brain/comments"
immunityRequests[9]="/brain/photos"
immunityRequests[10]="/brain/todos"
immunityRequests[9]="/brain/users"
 
workspaces=( $(http $ADMIN_HOST:$ADMIN_PORT/workspaces | jq -r '.data[].name') )

RANDOM=$$$(date +%s)

if [ "$ENABLE_LOW_TRAFFIC_MODE" = "true" ]; then echo "*** Running in Low Traffic Mode"; fi

while :
do
  if [ "$ENABLE_LOW_TRAFFIC_MODE" = "true" ]; then sleep 1.$[ ( $RANDOM % 30 )  ]s; fi
  http $PROXY_HOST:${ports[$RANDOM % ${#ports[@]} ]}/httpbin Host:kong apikey:httpbinKey Authorization:'Basic aHR0cGJpbjpodHRwYmluUGFzcw=='
  if [ "$ENABLE_LOW_TRAFFIC_MODE" = "true" ]; then sleep 1.$[ ( $RANDOM % 30 )  ]s; fi
  http $PROXY_HOST:${ports[$RANDOM % ${#ports[@]} ]}/httpbin Host:kong apikey:anotherKey Authorization:'Basic YW5vdGhlclVzZXJuYW1lOmFub3RoZXJQYXNz'
  if [ "$ENABLE_LOW_TRAFFIC_MODE" = "true" ]; then sleep 1.$[ ( $RANDOM % 30 )  ]s; fi
  http $PROXY_HOST:${ports[$RANDOM % ${#ports[@]} ]}/httpbin Host:kong apikey:wrongKey Authorization:'Basic xxxxxxxxx'
  sleep .$[ ( $RANDOM % 30 )  ]s
  http $PROXY_HOST:${ports[$RANDOM % ${#ports[@]} ]}/${workspaces[$RANDOM % ${#workspaces[@]} ]}/httpbin
  if [ "$ENABLE_LOW_TRAFFIC_MODE" = "true" ]; then sleep 1.$[ ( $RANDOM % 30 )  ]s; fi
  http $PROXY_HOST:${ports[$RANDOM % ${#ports[@]} ]}/${workspaces[$RANDOM % ${#workspaces[@]} ]}/httpbin
  sleep .$[ ( $RANDOM % 30 )  ]s
  echo "*** Sending traffic to Developer Portal..."
  http $PROXY_HOST:${ports[$RANDOM % ${#ports[@]} ]}/keyAuth apikey:developer
  if [ "$ENABLE_BRAIN_IMMUNITY" = true ] ; 
  then
    sleep .$[ ( $RANDOM % 30 )  ]s
    echo "*** Sending traffic to Immunity..."
    http $PROXY_HOST:${ports[$RANDOM % ${#ports[@]} ]}${immunityRequests[$RANDOM % ${#immunityRequests[@]} ]}  
  fi
done
