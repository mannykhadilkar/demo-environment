# Load generator
The scripts in this folder will generate load on your demo including all workspaces and even includes some errors for a real-world mirroring. The difference between the two files is one using different ports (8000, 8010, 8020) for three different nodes while the other scripts assume a load balancer is in place (or Kubernetes Ingress, HAProxy, ALB etc…).
