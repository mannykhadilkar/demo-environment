#!/bin/sh
echo "Sending requests to Kong and Brain now to get training data"
RANDOM=$$$(date +%s)
NUMBER_OF_RUNS=50

for ((i=1;i<=$NUMBER_OF_RUNS;i++)); 
do 
  echo "Running $i out of $NUMBER_OF_RUNS\r\c"
  http $PROXY_HOST:$PROXY_PORT/brain/posts > /dev/null 2>&1 &
  http $PROXY_HOST:$PROXY_PORT/brain/albums > /dev/null 2>&1 &
  http $PROXY_HOST:$PROXY_PORT/brain/posts/1 > /dev/null 2>&1 &
  http POST $PROXY_HOST:$PROXY_PORT/brain/albums id=101 title="My added album" userId=10> /dev/null 2>&1
  http $PROXY_HOST:$PROXY_PORT/brain/albums/101 > /dev/null 2>&1
  http DELETE $PROXY_HOST:$PROXY_PORT/brain/albums/101 > /dev/null 2>&1
  http $PROXY_HOST:$PROXY_PORT/brain/posts/12 > /dev/null 2>&1 &
done

echo "Training data collected now - waiting a few seconds for sending all of them to brain"
sleep 10

echo "Starting training now"
curl -d '{"start":"2019-01-01 11:00:00", "end":"2022-10-01 11:32:00"}' -H "Content-Type: application/json" -X POST http://$BRAIN_HOST:$BRAIN_PORT/trainer
