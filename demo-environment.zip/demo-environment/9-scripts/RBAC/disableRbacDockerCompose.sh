#!/bin/sh
echo "KONG_ENFORCE_RBAC=off KONG_ADMIN_GUI_AUTH=\"\" KONG_ADMIN_GUI_SESSION_CONF='' kong reload exit" | docker exec -i kong-ent1 /bin/sh
