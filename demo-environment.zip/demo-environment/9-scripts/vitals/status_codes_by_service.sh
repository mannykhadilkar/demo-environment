#!/bin/sh
echo "Shows status codes per service"
SERVICE_ID=$(http $ADMIN_HOST:$ADMIN_PORT/services/combined | jq -r '.id' )
http :8001/vitals/status_codes/by_service service_id==$SERVICE_ID interval==minutes
