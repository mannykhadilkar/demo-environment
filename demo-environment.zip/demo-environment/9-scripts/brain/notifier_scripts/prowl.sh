#!/bin/sh
alert_type=$1
title=$2
text=$3
detected_at=$4
url=$5
route_id=$6
service_id=$7
system_restored=$8
severity=$9

if [ "${PROWL_KEY}" ]; then
  http -f POST https://api.prowlapp.com/publicapi/add apikey=$PROWL_KEY priority=-1 event="[$severity] $title" description="$text at $url" application=Kong >/dev/null
fi
