#!/bin/sh
alert_type=$1
title=$2
text=$3
detected_at=$4
url=$5
route_id=$6
service_id=$7
system_restored=$8
severity=$9

if [ "${SLACK_HOOK}" ]; then
  http $SLACK_HOOK text="[$severity] $title $text at $url"
fi
