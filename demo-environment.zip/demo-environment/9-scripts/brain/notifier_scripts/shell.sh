#!/bin/sh
alert_type=$1
title=$2
text=$3
detected_at=$4
url=$5
route_id=$6
service_id=$7
system_restored=$8
severity=$9

echo "**************"
echo "Alert: [$severity] $alert_type detected at $detected_at"
echo "$title : $text"
echo "Affected Service: $url (route: $route_id, service: $service_id)"
echo "System has been restored: $system_restored"
echo "**************"
