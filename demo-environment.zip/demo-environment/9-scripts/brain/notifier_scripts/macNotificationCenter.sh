#!/bin/sh
alert_type=$1
title=$2
text=$3
detected_at=$4
url=$5
route_id=$6
service_id=$7
system_restored=$8
severity=$9

osascript -e "display notification \"$text on service $url (route: $route_id, service: $service_id) detected at $detected_at\n on \" with title \"Kong Brain [$severity]\" subtitle \"$title\""
