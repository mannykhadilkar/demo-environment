#!/bin/sh
curl -d '{"start":"2019-01-01 11:00:00", "end":"2022-10-01 11:32:00"}' -H "Content-Type: application/json" -X POST http://$BRAIN_HOST:$BRAIN_PORT/trainer
