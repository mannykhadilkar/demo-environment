#!/bin/sh
http http://$BRAIN_HOST:$BRAIN_PORT/alerts/config
