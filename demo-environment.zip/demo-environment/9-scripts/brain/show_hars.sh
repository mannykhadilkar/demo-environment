#!/bin/sh
http http://$BRAIN_HOST:$BRAIN_PORT/hars\?alert_id=1
