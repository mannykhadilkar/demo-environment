#!/bin/sh
ALERTS=$(http $BRAIN_HOST:$BRAIN_PORT/alerts | jq -c -r '.alerts[] | @base64')
for alert in $ALERTS; do 
  alert_type=$(echo ${alert} | base64 --decode | jq -r -c '.alert_type')
  detected_at=$(echo ${alert} | base64 --decode | jq -r -c '.detected_at')
  route_id=$(echo ${alert} | base64 --decode | jq -r -c '.route_id')
  service_id=$(echo ${alert} | base64 --decode | jq -r -c '.service_id')
  system_restored=$(echo ${alert} | base64 --decode | jq -r -c '.system_restored')
  url=$(echo ${alert} | base64 --decode | jq -r -c '.url')
  severity=$(echo ${alert} | base64 --decode | jq -r -c '.severity')
  # Summary
  title=$(echo ${alert} | base64 --decode | jq -r -c '.state' | jq -c -r '.[].title | gsub("[\\n\\t]"; "")')
  text=$(echo ${alert} | base64 --decode | jq -r -c '.state' | jq -c -r '.[].text | gsub("[\\n\\t]"; "")')

  for script in ./notifier_scripts/*.sh; do 
    . $script $alert_type "$title" "$text" "$detected_at" $url $route_id $service_id $system_restored $severity
  done
done
