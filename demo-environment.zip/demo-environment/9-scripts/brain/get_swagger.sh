#!/bin/sh
http http://$BRAIN_HOST:$BRAIN_PORT/get_swagger\?host=$PROXY_HOST\&openapi_version=3
