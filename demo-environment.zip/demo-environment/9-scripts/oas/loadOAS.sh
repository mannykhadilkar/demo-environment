#!/bin/sh
if [ "$1" != '' ]; then
  docker cp $1 kong-ent1:/tmp/
  echo "openapi2kong /tmp/$1 > /tmp/kong-oas.yaml; kong config db_import /tmp/kong-oas.yaml; exit" | docker exec -i kong-ent1 /bin/sh
else
  echo "Please supply an OpenAPI v3 YAML file as input."
fi
