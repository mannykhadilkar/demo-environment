#!/bin/sh
IDP=$1
WORKSPACE=default
http http://$ADMIN_HOST:$ADMIN_PORT/workspaces/$WORKSPACE > current.json
jq -c '.config.portal_auth="openid-connect"' current.json > test.json

http -f PATCH http://$ADMIN_HOST:$ADMIN_PORT/workspaces/$WORKSPACE \
  config.portal_auth=openid-connect
 # config.portal_auth_conf:=@$IDP.json

  #config.portal_auth:=openid-connect \
