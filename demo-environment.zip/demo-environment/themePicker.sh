#!/bin/sh
echo "Kong theme selector - remember to always run it with a leading \". \" like \". ./themeChooser.sh"
START_PWD=$PWD
THEMES=( $(find 2-create-contents/subScripts/themes/*.sh -type f | xargs basename | sed 's/\.sh//g') )
select THEME in "${THEMES[@]}"
do
  export PORTAL_THEME=$THEME
  echo "I have set PORTAL_THEME now to $THEME"
  break
done
