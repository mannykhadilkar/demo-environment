Before start with KONG please read the CONTRIBUTING.md guidelines to learn where and on which 
channel you can search for the help and can ask genral question

Also read the CODE_OF_CONDUCT.md to get the idea about code format and policies of KONG


### Summary

SUMMARY_GOES_HERE
<!---- Please write summery as elaborative as you can it will help the contributors ---->

### Implemenations

1.
2.
3.
4.

### Changed Docs

1.
2.
3.
4.

### Issues Resolved

1.
2.
3.
4.




